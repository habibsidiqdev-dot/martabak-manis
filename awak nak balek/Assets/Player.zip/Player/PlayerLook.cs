using UnityEngine;

[RequireComponent(typeof(PlayerInput))]
public class PlayerLook : MonoBehaviour
{
    [SerializeField] private Transform cameraPivot;
    [SerializeField] private float sensitivity = 0.1f;
    [SerializeField] private float maxPitch = 85f;

    private PlayerInput _input;
    private float _pitch;

    private void Awake()
    {
        _input = GetComponent<PlayerInput>();
    }

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        Vector2 delta = _input.lookInput * sensitivity;

        transform.Rotate(Vector3.up, delta.x);                       // putar badan (kiri/kanan)
        _pitch = Mathf.Clamp(_pitch - delta.y, -maxPitch, maxPitch); // lihat atas/bawah
        cameraPivot.localRotation = Quaternion.Euler(_pitch, 0f, 0f);
    }
}
