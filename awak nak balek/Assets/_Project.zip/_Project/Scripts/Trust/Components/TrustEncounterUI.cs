using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace TrustSystem
{
    /// <summary>
    /// Tampilan encounter: kotak Deskripsi Kejadian, kotak Dialogue, daftar Pilihan.
    /// UI ini "bodoh": hanya menampilkan dan melempar event. Aturannya ada di TrustEncounter.
    /// Pasang script ini di objek yang SELALU aktif (mis. Canvas); panel yang di-toggle diisi ke 'root'.
    /// </summary>
    public class TrustEncounterUI : MonoBehaviour
    {
        [Serializable]
        private class ApproachButton
        {
            public Approach approach;
            public Button button;
            public TMP_Text label;
        }

        [Header("Root panel (yang di-show/hide)")]
        [SerializeField] private GameObject root;

        [Header("Crosshair")]
        [SerializeField] private Image crosshairImage;

        [Header("Teks")]
        [SerializeField] private TMP_Text npcNameLabel;
        [SerializeField] private TMP_Text descriptionLabel;   // Deskripsi Kejadian (berisi petunjuk bahasa tubuh)
        [SerializeField] private TMP_Text dialogueLabel;      // Dialogue NPC
        [SerializeField] private TMP_Text resonanceLabel;
        [SerializeField] private TMP_Text turnsLabel;

        [Header("Pilihan pendekatan (isi 4: OBS, KNO, ACT, SIL)")]
        [SerializeField] private ApproachButton[] approachButtons;

        [Header("Item")]
        [SerializeField] private RectTransform itemContainer;
        [SerializeField] private Button itemButtonPrefab;      // prefab Button dengan 1 TMP_Text di dalamnya

        [Header("Hasil")]
        [SerializeField] private GameObject resultPanel;
        [SerializeField] private TMP_Text resultLabel;
        [SerializeField] private Button retryButton;
        [SerializeField] private Button closeButton;

        public event Action<Approach> ApproachChosen;
        public event Action<int> ItemChosen;   // index item di inventori
        public event Action RetryClicked;
        public event Action CloseClicked;

        private readonly List<Button> _itemButtons = new List<Button>();
        private UnityAction[] _approachActions;
        private UnityAction _retryAction;
        private UnityAction _closeAction;
        private bool _initialized;

        private void Awake() => TryInitialize();

        private void OnEnable() => TryInitialize();

        private bool TryInitialize()
        {
            if (_initialized) return true;
            if (root == null || npcNameLabel == null || descriptionLabel == null || dialogueLabel == null ||
                resonanceLabel == null || turnsLabel == null || approachButtons == null || approachButtons.Length != 4 ||
                itemContainer == null || itemButtonPrefab == null || resultPanel == null || resultLabel == null ||
                retryButton == null || closeButton == null)
                return false;

            foreach (ApproachButton entry in approachButtons)
            {
                if (entry == null || entry.button == null) return false;
            }

            BindButtonListeners();
            root.SetActive(false);
            _initialized = true;
            return true;
        }

        public void Show(string npcName)
        {
            if (!TryInitialize())
            {
                Debug.LogError($"{name}: TrustEncounterUI has missing or invalid Inspector references.", this);
                return;
            }
            BindButtonListeners();
            if (npcNameLabel != null) npcNameLabel.text = npcName;
            HideResult();
            root.SetActive(true);
            if (crosshairImage != null) crosshairImage.enabled = false;
        }

        public void Hide()
        {
            root.SetActive(false);
            if (crosshairImage != null) crosshairImage.enabled = true;
        }

        private void BindButtonListeners()
        {
            if (_approachActions != null)
            {
                for (int i = 0; i < _approachActions.Length && i < approachButtons.Length; i++)
                    if (approachButtons[i]?.button != null && _approachActions[i] != null)
                        approachButtons[i].button.onClick.RemoveListener(_approachActions[i]);
            }

            _approachActions = new UnityAction[approachButtons.Length];
            for (int i = 0; i < approachButtons.Length; i++)
            {
                ApproachButton entry = approachButtons[i];
                Approach captured = entry.approach;
                _approachActions[i] = () => ApproachChosen?.Invoke(captured);
                entry.button.onClick.AddListener(_approachActions[i]);
                if (entry.label != null)
                    entry.label.text = $"[{captured.ShortCode()}]  {captured.Label()}";
            }

            if (_retryAction != null) retryButton.onClick.RemoveListener(_retryAction);
            if (_closeAction != null) closeButton.onClick.RemoveListener(_closeAction);
            _retryAction = () => RetryClicked?.Invoke();
            _closeAction = () => CloseClicked?.Invoke();
            retryButton.onClick.AddListener(_retryAction);
            closeButton.onClick.AddListener(_closeAction);
        }

        public void SetDescription(string text) => descriptionLabel.text = text;
        public void SetDialogue(string text) => dialogueLabel.text = text;

        public void SetStatus(int resonance, int target, int turnsLeft, bool shieldActive)
        {
            resonanceLabel.text = $"Resonansi {resonance} / {target}";
            turnsLabel.text = shieldActive ? $"Giliran {turnsLeft}   [Perisai aktif]" : $"Giliran {turnsLeft}";
        }

        /// <summary>Kunci/buka semua tombol pilihan & item (mis. saat animasi hasil berjalan).</summary>
        public void SetInputEnabled(bool isEnabled)
        {
            foreach (ApproachButton entry in approachButtons)
                entry.button.interactable = isEnabled;

            foreach (Button itemButton in _itemButtons)
                itemButton.interactable = isEnabled;
        }

        public void SetItems(IReadOnlyList<TrustItemData> items, bool interactable)
        {
            if (itemContainer != null)
            {
                // Clear the container itself as well as the tracked list. This also cleans
                // generated buttons left behind by an Editor script reload with scene reload disabled.
                for (int i = itemContainer.childCount - 1; i >= 0; i--)
                {
                    GameObject old = itemContainer.GetChild(i).gameObject;
                    old.SetActive(false);
                    Destroy(old);
                }
            }
            _itemButtons.Clear();

            if (itemContainer == null || itemButtonPrefab == null) return;

            for (int i = 0; i < items.Count; i++)
            {
                int index = i;
                Button itemButton = Instantiate(itemButtonPrefab, itemContainer);

                TMP_Text label = itemButton.GetComponentInChildren<TMP_Text>();
                if (label != null) label.text = items[i].DisplayName;

                itemButton.interactable = interactable;
                itemButton.onClick.AddListener(() => ItemChosen?.Invoke(index));
                _itemButtons.Add(itemButton);
            }
        }

        public void ShowResult(bool won, string message)
        {
            resultPanel.SetActive(true);
            resultLabel.text = message;
            retryButton.gameObject.SetActive(!won);   // coba lagi hanya kalau kalah
        }

        public void HideResult() => resultPanel.SetActive(false);
    }
}
