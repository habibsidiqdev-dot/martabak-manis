using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace TrustSystem
{
    /// <summary>
    /// Pasang di NPC (harus punya Collider). Menghubungkan Interact -> logika (TrustEncounter) -> UI,
    /// mengunci input pemain selama encounter, dan mengelola item + retry.
    /// </summary>
    public class TrustNpc : MonoBehaviour, IInteractable
    {
        [SerializeField] private TrustEncounterData data;
        [SerializeField] private TrustEncounterUI ui;
        [SerializeField, Min(0f)] private float resultDelay = 1.2f;

        [Tooltip("Dipanggil saat pemain menutup panel setelah MENANG (buka pintu, lanjut cerita, dll).")]
        [SerializeField] private UnityEvent onTrustWon;

        private static readonly IReadOnlyList<TrustItemData> NoItems = new List<TrustItemData>();

        private TrustEncounter _encounter;
        private PlayerInputReader _playerInput;
        private PlayerInventory _inventory;
        private List<TrustItemData> _inventorySnapshot;
        private bool _active;
        private bool _resolving;
        private bool _won;

        // ---------- IInteractable ----------

        public string Prompt
        {
            get
            {
                string npcName = data != null ? data.NpcName : "NPC";
                return $"[E] Bicara dengan {npcName}";
            }
        }

        public bool CanInteract => !_active && !_won;

        public void Interact(GameObject interactor)
        {
            if (!CanInteract) return;

            if (data == null || ui == null)
            {
                Debug.LogError($"{name}: 'data' atau 'ui' belum di-assign di Inspector.", this);
                return;
            }

            _playerInput = interactor.GetComponent<PlayerInputReader>();
            _inventory = interactor.GetComponent<PlayerInventory>();   // boleh null (tanpa item)

            _active = true;
            if (_playerInput != null) _playerInput.SetGameplayEnabled(false);

            ui.ApproachChosen += OnApproachChosen;
            ui.ItemChosen += OnItemChosen;
            ui.RetryClicked += OnRetry;
            ui.CloseClicked += OnClose;

            ui.Show(data.NpcName);
            BeginEncounter();
        }

        // ---------- Alur encounter ----------

        private void BeginEncounter()
        {
            // Item yang dipakai di percobaan yang KALAH dikembalikan saat retry / tutup.
            if (_inventory != null) _inventorySnapshot = _inventory.Snapshot();

            _encounter = new TrustEncounter(data.MaxTurns, data.TargetResonance, data.MoodPool, data.ClueChance);
            _encounter.Begin();

            ui.HideResult();
            ui.SetDialogue(data.IntroDialogue);
            PresentTurn(data.IntroDescription);
        }

        private void PresentTurn(string preface)
        {
            var sb = new StringBuilder();

            if (!string.IsNullOrEmpty(preface))
                sb.AppendLine(preface).AppendLine();

            IReadOnlyList<Clue> clues = _encounter.Clues;
            if (clues.Count == 0)
            {
                sb.Append(data.NoClueText);
            }
            else
            {
                for (int i = 0; i < clues.Count; i++)
                {
                    string line = data.GetClueText(clues[i].Approach, clues[i].Mood);
                    if (!string.IsNullOrEmpty(line)) sb.AppendLine(line);
                }
            }

            ui.SetDescription(sb.ToString().TrimEnd());
            RefreshStatus();
            RefreshItems(true);
            ui.SetInputEnabled(true);
        }

        private void OnApproachChosen(Approach approach)
        {
            if (_resolving || _encounter == null || _encounter.State != EncounterState.AwaitingChoice) return;

            ChoiceResult result = _encounter.Choose(approach);
            StartCoroutine(ResolveRoutine(result));
        }

        private IEnumerator ResolveRoutine(ChoiceResult result)
        {
            _resolving = true;
            ui.SetInputEnabled(false);
            RefreshStatus();

            string reaction = data.GetReaction(
                result.Approach,
                result.Mood
            );
            if (!string.IsNullOrEmpty(reaction)) ui.SetDialogue(reaction);

            string feedback = $"Kamu memilih {result.Approach.Label()}.   Resonansi {result.Delta.ToString("+0;-0;0")}";
            if (result.ShieldAbsorbed) feedback += "   (Perisai menahan penolakan)";
            ui.SetDescription(feedback);

            yield return new WaitForSeconds(resultDelay);

            switch (_encounter.State)
            {
                case EncounterState.Won:
                    _won = true;
                    ui.SetDialogue(data.WinDialogue);
                    ui.ShowResult(true, $"{data.NpcName} mempercayaimu.");
                    break;

                case EncounterState.Lost:
                    ui.SetDialogue(data.LoseDialogue);
                    ui.ShowResult(false, $"{data.NpcName} belum percaya. Resonansi {_encounter.Resonance} / {_encounter.TargetResonance}.");
                    break;

                default:
                    PresentTurn(null);   // giliran berikutnya, mood sudah diputar ulang di TrustEncounter
                    break;
            }

            _resolving = false;
        }

        // ---------- Item ----------

        private void OnItemChosen(int index)
        {
            if (_resolving || _inventory == null || _encounter == null) return;
            if (_encounter.State != EncounterState.AwaitingChoice) return;
            if (index < 0 || index >= _inventory.Items.Count) return;

            TrustItemData item = _inventory.Items[index];
            if (!_encounter.UseItem(item.Effect)) return;   // tidak bisa dipakai -> item tidak terkonsumsi

            _inventory.Remove(item);

            if (item.Effect == TrustItemEffect.RerollMood)
            {
                PresentTurn(null);   // petunjuk berubah, tampilkan ulang
            }
            else
            {
                RefreshStatus();
                RefreshItems(true);
            }
        }

        // ---------- Retry / tutup ----------

        private void OnRetry()
        {
            if (_resolving || _encounter == null || _encounter.State != EncounterState.Lost) return;

            if (_inventory != null && _inventorySnapshot != null) _inventory.Restore(_inventorySnapshot);
            BeginEncounter();
        }

        private void OnClose()
        {
            bool won = _won;
            Cleanup(restoreItems: !won);
            if (won) onTrustWon.Invoke();
        }

        private void OnDisable() => Cleanup(restoreItems: true);

        private void Cleanup(bool restoreItems)
        {
            if (!_active) return;

            StopAllCoroutines();
            _resolving = false;

            if (ui != null)
            {
                ui.ApproachChosen -= OnApproachChosen;
                ui.ItemChosen -= OnItemChosen;
                ui.RetryClicked -= OnRetry;
                ui.CloseClicked -= OnClose;
                ui.Hide();
            }

            if (restoreItems && _inventory != null && _inventorySnapshot != null)
                _inventory.Restore(_inventorySnapshot);

            if (_playerInput != null) _playerInput.SetGameplayEnabled(true);

            _active = false;
        }

        // ---------- Helper UI ----------

        private void RefreshStatus()
        {
            ui.SetStatus(_encounter.Resonance, _encounter.TargetResonance, _encounter.TurnsLeft, _encounter.ShieldActive);
        }

        private void RefreshItems(bool interactable)
        {
            ui.SetItems(_inventory != null ? _inventory.Items : NoItems, interactable);
        }
    }
}
