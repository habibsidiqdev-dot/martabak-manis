using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TrustSystem.EditorTools
{
    /// <summary>
    /// Menu: Tools > Trust > Buat UI Screen Space.
    /// Menyusun hierarki TrustScreenUI di scene yang sedang terbuka (Canvas Overlay 1920x1080, roda 4 pilihan,
    /// petunjuk, dialogue, label nama, panel hasil) dan mengisi semua field TrustScreenEncounterUI.
    /// Letakkan file ini di folder bernama "Editor" (mis. _Project/Editor/).
    /// </summary>
    public static class TrustScreenUIBuilder
    {
        private static readonly Color PanelColor = new Color(.08f, .08f, .10f, .82f);
        private static readonly Color HintColor = new Color(.30f, .20f, .05f, .90f);
        private static readonly Color ButtonColor = new Color(.10f, .10f, .12f, .88f);
        private static readonly Color ButtonHover = new Color(.45f, .32f, .10f, .95f);
        private static readonly Color ButtonPressed = new Color(.95f, .72f, .25f, 1f);
        private static readonly Color TextColor = new Color(.96f, .94f, .90f, 1f);
        private static readonly Color MutedColor = new Color(.78f, .74f, .68f, 1f);
        private static readonly Color AccentColor = new Color(.98f, .80f, .38f, 1f);

        [MenuItem("Tools/Trust/Buat UI Screen Space")]
        private static void Build()
        {
            if (Object.FindFirstObjectByType<TrustScreenEncounterUI>(FindObjectsInactive.Include) != null &&
                !EditorUtility.DisplayDialog("UI Trust screen space",
                    "Di scene ini sudah ada TrustScreenEncounterUI. Buat satu lagi?", "Buat lagi", "Batal"))
                return;

            if (Object.FindFirstObjectByType<EventSystem>() == null)
                Debug.LogWarning("Scene tidak punya EventSystem: klik pada tombol tidak akan bekerja.");

            // ---------- Akar ----------
            GameObject root = new GameObject("TrustScreenUI", typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster));
            root.layer = LayerMask.NameToLayer("UI");

            Canvas canvas = root.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;

            CanvasScaler scaler = root.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = .5f;

            TrustScreenEncounterUI ui = root.AddComponent<TrustScreenEncounterUI>();

            RectTransform encounterRoot = NewRect("EncounterRoot", root.transform);
            Anchors(encounterRoot, Vector2.zero, Vector2.one);

            // ---------- Panel setengah layar ----------
            RectTransform panelRoot = NewRect("PanelRoot", encounterRoot);
            Anchors(panelRoot, Vector2.zero, new Vector2(.5f, 1f));

            // Roda
            RectTransform wheel = NewRect("Wheel", panelRoot);
            Place(wheel, new Vector2(.5f, .62f), Vector2.zero, new Vector2(600f, 600f));

            RectTransform disc = NewRect("CenterDisc", wheel);
            Place(disc, new Vector2(.5f, .5f), Vector2.zero, new Vector2(300f, 300f));
            Image discImage = AddImage(disc, PanelColor, false);
            discImage.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Knob.psd");

            TextMeshProUGUI caption = AddText("ResonanceCaption", wheel, "Resonansi", 28f, TextAlignmentOptions.Center, MutedColor, FontStyles.Normal);
            Place(caption.rectTransform, new Vector2(.5f, .5f), new Vector2(0f, 72f), new Vector2(260f, 40f));

            TextMeshProUGUI resonanceLabel = AddText("ResonanceLabel", wheel, "0 / 10", 64f, TextAlignmentOptions.Center, TextColor, FontStyles.Bold);
            Place(resonanceLabel.rectTransform, new Vector2(.5f, .5f), new Vector2(0f, 8f), new Vector2(260f, 84f));

            TextMeshProUGUI turnsLabel = AddText("TurnsLabel", wheel, "Giliran 5", 30f, TextAlignmentOptions.Center, AccentColor, FontStyles.Normal);
            Place(turnsLabel.rectTransform, new Vector2(.5f, .5f), new Vector2(0f, -66f), new Vector2(260f, 40f));

            // Urutan = Atas, Kanan, Bawah, Kiri  (OBS, KNO, ACT, SIL)
            Vector2[] positions =
            {
                new Vector2(0f, 210f), new Vector2(300f, 0f), new Vector2(0f, -210f), new Vector2(-300f, 0f)
            };
            string[] names = { "Button_OBS", "Button_KNO", "Button_ACT", "Button_SIL" };
            Button[] buttons = new Button[4];
            TextMeshProUGUI[] labels = new TextMeshProUGUI[4];
            for (int i = 0; i < 4; i++)
                buttons[i] = AddButton(names[i], wheel, positions[i], new Vector2(260f, 72f), "Pilihan", out labels[i]);

            // Petunjuk
            RectTransform hintBox = NewRect("HintBox", panelRoot);
            Anchors(hintBox, Vector2.zero, new Vector2(1f, 0f));
            hintBox.offsetMin = new Vector2(40f, 260f);
            hintBox.offsetMax = new Vector2(-40f, 330f);
            AddImage(hintBox, HintColor, false);
            TextMeshProUGUI hintLabel = AddText("HintLabel", hintBox, "Petunjuk bahasa tubuh NPC.", 28f, TextAlignmentOptions.MidlineLeft, AccentColor, FontStyles.Italic);
            Inset(hintLabel.rectTransform, 24f, 8f, 24f, 8f);

            // Dialogue
            RectTransform dialogueBox = NewRect("DialogueBox", panelRoot);
            Anchors(dialogueBox, Vector2.zero, new Vector2(1f, 0f));
            dialogueBox.offsetMin = new Vector2(40f, 40f);
            dialogueBox.offsetMax = new Vector2(-40f, 240f);
            AddImage(dialogueBox, PanelColor, false);
            TextMeshProUGUI dialogueLabel = AddText("DialogueLabel", dialogueBox, "Dialogue atau reaksi NPC.", 34f, TextAlignmentOptions.TopLeft, TextColor, FontStyles.Normal);
            Inset(dialogueLabel.rectTransform, 24f, 16f, 24f, 16f);

            // ---------- Label nama (anak langsung EncounterRoot) ----------
            RectTransform nameTag = NewRect("NameTag", encounterRoot);
            Place(nameTag, new Vector2(.5f, .5f), Vector2.zero, new Vector2(340f, 64f));
            AddImage(nameTag, PanelColor, false);
            TextMeshProUGUI npcNameLabel = AddText("NpcNameLabel", nameTag, "Nama NPC", 32f, TextAlignmentOptions.Center, TextColor, FontStyles.Bold);
            Inset(npcNameLabel.rectTransform, 12f, 4f, 12f, 4f);

            // ---------- Panel hasil ----------
            RectTransform resultPanel = NewRect("ResultPanel", encounterRoot);
            Place(resultPanel, new Vector2(.5f, .5f), Vector2.zero, new Vector2(900f, 420f));
            AddImage(resultPanel, PanelColor, true);
            TextMeshProUGUI resultLabel = AddText("ResultLabel", resultPanel, "Hasil", 40f, TextAlignmentOptions.Center, TextColor, FontStyles.Normal);
            Inset(resultLabel.rectTransform, 40f, 150f, 40f, 40f);

            TextMeshProUGUI retryLabel;
            Button retryButton = AddButton("RetryButton", resultPanel, new Vector2(-170f, -140f), new Vector2(300f, 80f), "Coba lagi", out retryLabel);
            TextMeshProUGUI closeLabel;
            Button closeButton = AddButton("CloseButton", resultPanel, new Vector2(170f, -140f), new Vector2(300f, 80f), "Tutup", out closeLabel);
            resultPanel.gameObject.SetActive(false);

            // ---------- Isi field Inspector ----------
            SerializedObject so = new SerializedObject(ui);
            SetRef(so, "encounterRoot", encounterRoot.gameObject);
            SetRef(so, "panelRoot", panelRoot);
            SetRef(so, "nameTag", nameTag);
            SetRef(so, "npcNameLabel", npcNameLabel);
            SetRef(so, "hintLabel", hintLabel);
            SetRef(so, "dialogueLabel", dialogueLabel);
            SetRef(so, "resonanceLabel", resonanceLabel);
            SetRef(so, "turnsLabel", turnsLabel);
            SetRef(so, "resultPanel", resultPanel.gameObject);
            SetRef(so, "resultLabel", resultLabel);
            SetRef(so, "retryButton", retryButton);
            SetRef(so, "closeButton", closeButton);

            SerializedProperty array = so.FindProperty("approachButtons");
            if (array != null)
            {
                array.arraySize = 4;
                for (int i = 0; i < 4; i++)
                {
                    SerializedProperty element = array.GetArrayElementAtIndex(i);
                    element.FindPropertyRelative("approach").enumValueIndex = i;   // 0..3 = OBS, KNO, ACT, SIL
                    element.FindPropertyRelative("button").objectReferenceValue = buttons[i];
                    element.FindPropertyRelative("label").objectReferenceValue = labels[i];
                }
            }

            // Crosshair: ambil dari TrustHudView lama kalau ada.
            TrustHudView oldHud = Object.FindFirstObjectByType<TrustHudView>(FindObjectsInactive.Include);
            if (oldHud != null)
            {
                SerializedProperty crosshair = new SerializedObject(oldHud).FindProperty("crosshairImage");
                if (crosshair != null) SetRef(so, "crosshairImage", crosshair.objectReferenceValue);
            }

            so.ApplyModifiedPropertiesWithoutUndo();

            Undo.RegisterCreatedObjectUndo(root, "Buat UI Trust screen space");
            Selection.activeGameObject = root;
            EditorSceneManager.MarkSceneDirty(root.scene);
            Debug.Log("TrustScreenUI dibuat. Isi field 'Ui' di setiap TrustNpc dengan objek ini.", root);
        }

        // ---------- Helper ----------

        private static void SetRef(SerializedObject so, string field, Object value)
        {
            SerializedProperty property = so.FindProperty(field);
            if (property == null)
            {
                Debug.LogWarning($"Field '{field}' tidak ditemukan di TrustScreenEncounterUI.");
                return;
            }
            property.objectReferenceValue = value;
        }

        private static RectTransform NewRect(string name, Transform parent)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.layer = LayerMask.NameToLayer("UI");
            RectTransform rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            return rt;
        }

        private static void Anchors(RectTransform rt, Vector2 min, Vector2 max)
        {
            rt.anchorMin = min;
            rt.anchorMax = max;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        private static void Place(RectTransform rt, Vector2 anchor, Vector2 position, Vector2 size)
        {
            rt.anchorMin = anchor;
            rt.anchorMax = anchor;
            rt.pivot = new Vector2(.5f, .5f);
            rt.anchoredPosition = position;
            rt.sizeDelta = size;
        }

        private static void Inset(RectTransform rt, float left, float bottom, float right, float top)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(left, bottom);
            rt.offsetMax = new Vector2(-right, -top);
        }

        private static Image AddImage(RectTransform rt, Color color, bool raycast)
        {
            Image image = rt.gameObject.AddComponent<Image>();
            image.color = color;
            image.raycastTarget = raycast;
            return image;
        }

        private static TextMeshProUGUI AddText(string name, Transform parent, string text, float size,
            TextAlignmentOptions alignment, Color color, FontStyles style)
        {
            RectTransform rt = NewRect(name, parent);
            TextMeshProUGUI label = rt.gameObject.AddComponent<TextMeshProUGUI>();
            label.text = text;
            label.fontSize = size;
            label.alignment = alignment;
            label.color = color;
            label.fontStyle = style;
            label.raycastTarget = false;
            return label;
        }

        private static Button AddButton(string name, Transform parent, Vector2 position, Vector2 size,
            string text, out TextMeshProUGUI label)
        {
            RectTransform rt = NewRect(name, parent);
            Place(rt, new Vector2(.5f, .5f), position, size);

            Image image = AddImage(rt, Color.white, true);   // warna akhir = white x ColorBlock
            Button button = rt.gameObject.AddComponent<Button>();
            button.targetGraphic = image;
            button.navigation = new Navigation { mode = Navigation.Mode.None };

            ColorBlock colors = button.colors;
            colors.normalColor = ButtonColor;
            colors.highlightedColor = ButtonHover;
            colors.pressedColor = ButtonPressed;
            colors.selectedColor = ButtonColor;
            colors.disabledColor = new Color(.10f, .10f, .12f, .40f);
            colors.colorMultiplier = 1f;
            colors.fadeDuration = .08f;
            button.colors = colors;

            label = AddText("Label", rt, text, 30f, TextAlignmentOptions.Center, TextColor, FontStyles.Normal);
            Inset(label.rectTransform, 8f, 4f, 8f, 4f);
            return button;
        }
    }
}
