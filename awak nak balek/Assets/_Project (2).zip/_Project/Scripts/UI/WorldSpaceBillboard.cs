using UnityEngine;

/// <summary>Keeps a World Space UI panel facing a cached camera without camera lookups per frame.</summary>
public sealed class WorldSpaceBillboard : MonoBehaviour
{
    [SerializeField] private Camera targetCamera;
    [SerializeField] private bool keepUpright = true;

    public void SetCamera(Camera cameraToFace) => targetCamera = cameraToFace;

    private void LateUpdate()
    {
        if (targetCamera == null) return;

        Vector3 towardCamera = targetCamera.transform.position - transform.position;
        if (keepUpright) towardCamera.y = 0f;
        if (towardCamera.sqrMagnitude < .0001f) return;

        // Keep UI's local X/Y aligned with the camera while presenting its readable side.
        Quaternion facing = Quaternion.LookRotation(towardCamera.normalized, targetCamera.transform.up);
        transform.rotation = facing * Quaternion.Euler(0f, 180f, 0f);
    }
}
