using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace TrustSystem
{
    /// <summary>
    /// Pasang di NPC (harus punya Collider). Menghubungkan Interact -> logika (TrustEncounter) -> UI,
    /// mengunci input pemain selama encounter, dan mengelola item + retry.
    /// UI diakses lewat ITrustEncounterView, jadi bisa tampilan lama (TrustEncounterUI)
    /// maupun tampilan world space (TrustWorldEncounterUI).
    /// </summary>
    public class TrustNpc : MonoBehaviour, IInteractable
    {
        [SerializeField] private TrustEncounterData data;

        [Tooltip("Komponen tampilan encounter. Harus mengimplementasikan ITrustEncounterView " +
                 "(TrustWorldEncounterUI atau TrustEncounterUI).")]
        [SerializeField] private MonoBehaviour ui;

        [Tooltip("Titik di NPC tempat UI world space berpusat (sekitar dada). " +
                 "Kosong = posisi NPC + 1.2 m ke atas.")]
        [SerializeField] private Transform stageAnchor;

        [SerializeField, Min(0f)] private float resultDelay = 1.2f;

        [Tooltip("Dipanggil saat pemain menutup panel setelah MENANG (buka pintu, lanjut cerita, dll).")]
        [SerializeField] private UnityEvent onTrustWon;

        private static readonly IReadOnlyList<TrustItemData> NoItems = new List<TrustItemData>();

        private ITrustEncounterView _view;
        private TrustEncounter _encounter;
        private PlayerInputReader _playerInput;
        private PlayerInventory _inventory;
        private List<TrustItemData> _inventorySnapshot;
        private bool _active;
        private bool _resolving;
        private bool _won;

        private Vector3 AnchorPosition =>
            stageAnchor != null ? stageAnchor.position : transform.position + Vector3.up * 1.2f;

        private void OnValidate()
        {
            if (ui != null && !(ui is ITrustEncounterView))
                Debug.LogWarning($"{name}: 'ui' harus komponen yang mengimplementasikan ITrustEncounterView.", this);
        }

        // ---------- IInteractable ----------

        public string Prompt
        {
            get
            {
                string npcName = data != null ? data.NpcName : "NPC";
                return $"[E] Bicara dengan {npcName}";
            }
        }

        public bool CanInteract => !_active && !_won;

        public void Interact(GameObject interactor)
        {
            if (!CanInteract) return;

            _view = ui as ITrustEncounterView;
            if (data == null || _view == null)
            {
                Debug.LogError($"{name}: 'data' belum di-assign, atau 'ui' bukan ITrustEncounterView.", this);
                return;
            }

            _playerInput = interactor.GetComponent<PlayerInputReader>();
            _inventory = interactor.GetComponent<PlayerInventory>();   // boleh null (tanpa item)

            Camera viewer = interactor.GetComponentInChildren<Camera>();
            if (viewer == null) viewer = Camera.main;

            _active = true;
            if (_playerInput != null) _playerInput.SetGameplayEnabled(false);

            _view.ApproachChosen += OnApproachChosen;
            _view.ItemChosen += OnItemChosen;
            _view.RetryClicked += OnRetry;
            _view.CloseClicked += OnClose;

            _view.Show(data.NpcName, AnchorPosition, viewer);
            BeginEncounter();
        }

        // ---------- Alur encounter ----------

        private void BeginEncounter()
        {
            // Item yang dipakai di percobaan yang KALAH dikembalikan saat retry / tutup.
            if (_inventory != null) _inventorySnapshot = _inventory.Snapshot();

            _encounter = new TrustEncounter(data.MaxTurns, data.TargetResonance, data.MoodPool, data.ClueChance);
            _encounter.Begin();

            _view.HideResult();
            _view.SetDialogue(data.IntroDialogue);
            PresentTurn(data.IntroDescription);
        }

        private void PresentTurn(string preface)
        {
            var sb = new StringBuilder();

            if (!string.IsNullOrEmpty(preface))
                sb.AppendLine(preface).AppendLine();

            IReadOnlyList<Clue> clues = _encounter.Clues;
            if (clues.Count == 0)
            {
                sb.Append(data.NoClueText);
            }
            else
            {
                for (int i = 0; i < clues.Count; i++)
                {
                    string line = data.GetClueText(clues[i].Approach, clues[i].Mood);
                    if (!string.IsNullOrEmpty(line)) sb.AppendLine(line);
                }
            }

            _view.SetDescription(sb.ToString().TrimEnd());
            RefreshStatus();
            RefreshItems(true);
            _view.SetInputEnabled(true);
        }

        private void OnApproachChosen(Approach approach)
        {
            if (_resolving || _encounter == null || _encounter.State != EncounterState.AwaitingChoice) return;

            ChoiceResult result = _encounter.Choose(approach);
            StartCoroutine(ResolveRoutine(result));
        }

        private IEnumerator ResolveRoutine(ChoiceResult result)
        {
            _resolving = true;
            _view.SetInputEnabled(false);
            RefreshStatus();

            string reaction = data.GetReaction(
                result.Approach,
                result.Mood
            );
            if (!string.IsNullOrEmpty(reaction)) _view.SetDialogue(reaction);

            string feedback = $"Kamu memilih {result.Approach.Label()}.   Resonansi {result.Delta.ToString("+0;-0;0")}";
            if (result.ShieldAbsorbed) feedback += "   (Perisai menahan penolakan)";
            _view.SetDescription(feedback);

            yield return new WaitForSeconds(resultDelay);

            switch (_encounter.State)
            {
                case EncounterState.Won:
                    _won = true;
                    _view.SetDialogue(data.WinDialogue);
                    _view.ShowResult(true, $"{data.NpcName} mempercayaimu.");
                    break;

                case EncounterState.Lost:
                    _view.SetDialogue(data.LoseDialogue);
                    _view.ShowResult(false, $"{data.NpcName} belum percaya. Resonansi {_encounter.Resonance} / {_encounter.TargetResonance}.");
                    break;

                default:
                    PresentTurn(null);   // giliran berikutnya, mood sudah diputar ulang di TrustEncounter
                    break;
            }

            _resolving = false;
        }

        // ---------- Item ----------

        private void OnItemChosen(int index)
        {
            if (_resolving || _inventory == null || _encounter == null) return;
            if (_encounter.State != EncounterState.AwaitingChoice) return;
            if (index < 0 || index >= _inventory.Items.Count) return;

            TrustItemData item = _inventory.Items[index];
            if (!_encounter.UseItem(item.Effect)) return;   // tidak bisa dipakai -> item tidak terkonsumsi

            _inventory.Remove(item);

            if (item.Effect == TrustItemEffect.RerollMood)
            {
                PresentTurn(null);   // petunjuk berubah, tampilkan ulang
            }
            else
            {
                RefreshStatus();
                RefreshItems(true);
            }
        }

        // ---------- Retry / tutup ----------

        private void OnRetry()
        {
            if (_resolving || _encounter == null || _encounter.State != EncounterState.Lost) return;

            if (_inventory != null && _inventorySnapshot != null) _inventory.Restore(_inventorySnapshot);
            BeginEncounter();
        }

        private void OnClose()
        {
            bool won = _won;
            Cleanup(restoreItems: !won);
            if (won) onTrustWon.Invoke();
        }

        private void OnDisable() => Cleanup(restoreItems: true);

        private void Cleanup(bool restoreItems)
        {
            if (!_active) return;

            StopAllCoroutines();
            _resolving = false;

            // 'ui' dicek dengan null-check Unity: saat scene dibongkar komponennya bisa sudah hancur.
            if (ui != null && _view != null)
            {
                _view.ApproachChosen -= OnApproachChosen;
                _view.ItemChosen -= OnItemChosen;
                _view.RetryClicked -= OnRetry;
                _view.CloseClicked -= OnClose;
                _view.Hide();
            }

            if (restoreItems && _inventory != null && _inventorySnapshot != null)
                _inventory.Restore(_inventorySnapshot);

            if (_playerInput != null) _playerInput.SetGameplayEnabled(true);

            _active = false;
        }

        // ---------- Helper UI ----------

        private void RefreshStatus()
        {
            _view.SetStatus(_encounter.Resonance, _encounter.TargetResonance, _encounter.TurnsLeft, _encounter.ShieldActive);
        }

        private void RefreshItems(bool interactable)
        {
            _view.SetItems(_inventory != null ? _inventory.Items : NoItems, interactable);
        }
    }
}
