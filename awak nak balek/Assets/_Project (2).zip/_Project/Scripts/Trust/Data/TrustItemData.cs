using UnityEngine;

namespace TrustSystem
{
    [CreateAssetMenu(menuName = "Trust/Item", fileName = "TrustItem_New")]
    public class TrustItemData : ScriptableObject
    {
        [SerializeField] private string displayName = "Item";
        [SerializeField, TextArea(1, 3)] private string description;
        [SerializeField] private Sprite icon;
        [SerializeField] private TrustItemEffect effect;

        public string DisplayName => displayName;
        public string Description => description;
        public Sprite Icon => icon;
        public TrustItemEffect Effect => effect;
    }
}
