using System;
using System.Collections.Generic;
using TrustSystem;
using UnityEngine;

/// <summary>
/// Inventori sederhana. Satu entri = satu item (kalau punya 2 Perisai, ada 2 entri).
/// Kalau nanti punya sistem item umum, ganti TrustItemData dengan base class item kamu.
/// Pasang di root Player.
/// </summary>
public class PlayerInventory : MonoBehaviour
{
    [SerializeField] private List<TrustItemData> startingItems = new List<TrustItemData>();

    private readonly List<TrustItemData> _items = new List<TrustItemData>();
    private bool _initialized;

    public IReadOnlyList<TrustItemData> Items
    {
        get
        {
            EnsureInitialized();
            return _items;
        }
    }
    public event Action Changed;

    private void EnsureInitialized()
    {
        // The demo builder adds this component before assigning its serialized list.
        // In editor sessions with reload disabled, Awake can run before that assignment.
        if (_initialized || !Application.isPlaying) return;
        _items.Clear();
        if (startingItems != null) _items.AddRange(startingItems);
        _initialized = true;
    }

    public void Add(TrustItemData item)
    {
        EnsureInitialized();
        if (item == null) return;
        _items.Add(item);
        Changed?.Invoke();
    }

    public bool Remove(TrustItemData item)
    {
        EnsureInitialized();
        bool removed = _items.Remove(item);
        if (removed) Changed?.Invoke();
        return removed;
    }

    public List<TrustItemData> Snapshot()
    {
        EnsureInitialized();
        return new List<TrustItemData>(_items);
    }

    public void Restore(IEnumerable<TrustItemData> snapshot)
    {
        EnsureInitialized();
        _items.Clear();
        _items.AddRange(snapshot);
        Changed?.Invoke();
    }
}
