using TMPro;
using UnityEngine;

/// <summary>
/// Raycast dari kamera untuk mencari IInteractable di depan pemain.
/// Tombol Interact sudah ada di PlayerInputReader (OnInteractEvent); script ini yang memakainya.
/// Pasang di root Player (satu GameObject dengan PlayerInputReader).
/// </summary>
[RequireComponent(typeof(PlayerInputReader))]
public class PlayerInteractor : MonoBehaviour
{
    [Header("Raycast")]
    [SerializeField] private Transform viewOrigin;           // isi dengan Main Camera
    [SerializeField] private float interactDistance = 3f;
    [SerializeField] private LayerMask interactMask = ~0;    // Everything: tembok tetap menghalangi

    [Header("Prompt UI (opsional)")]
    [SerializeField] private GameObject promptRoot;
    [SerializeField] private TMP_Text promptLabel;

    private PlayerInputReader _input;
    private IInteractable _focused;
    private bool _subscribed;

    private void Awake()
    {
        _input = GetComponent<PlayerInputReader>();
    }

    private void OnEnable() => EnsureSubscribed();

    private void Start() => EnsureSubscribed();

    private void EnsureSubscribed()
    {
        if (_input == null) _input = GetComponent<PlayerInputReader>();
        if (_input != null && !_subscribed)
        {
            _input.OnInteractEvent += HandleInteract;
            _subscribed = true;
        }
    }

    private void OnDisable()
    {
        if (_input != null && _subscribed) _input.OnInteractEvent -= HandleInteract;
        _subscribed = false;
        SetFocus(null);
    }

    private void Update()
    {
        EnsureSubscribed();
        // Saat dialog/encounter aktif, jangan cari target & sembunyikan prompt
        if (!_input.GameplayEnabled)
        {
            SetFocus(null);
            return;
        }

        IInteractable target = null;

        if (Physics.Raycast(viewOrigin.position, viewOrigin.forward, out RaycastHit hit,
                interactDistance, interactMask, QueryTriggerInteraction.Ignore))
        {
            target = hit.collider.GetComponentInParent<IInteractable>();
            if (target != null && !target.CanInteract) target = null;
        }

        SetFocus(target);
    }

    private void HandleInteract()
    {
        if (_focused == null || !_focused.CanInteract) return;
        _focused.Interact(gameObject);
    }

    private void SetFocus(IInteractable target)
    {
        if (ReferenceEquals(_focused, target)) return;
        _focused = target;

        bool show = target != null;
        if (promptRoot != null) promptRoot.SetActive(show);
        if (show && promptLabel != null) promptLabel.text = target.Prompt;
    }
}
