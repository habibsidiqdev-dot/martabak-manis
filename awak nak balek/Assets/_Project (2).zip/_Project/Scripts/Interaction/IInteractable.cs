using UnityEngine;

/// <summary>Apa pun yang bisa diajak interaksi lewat tombol Interact (NPC, pintu, item, dll).</summary>
public interface IInteractable
{
    /// <summary>Teks prompt yang muncul saat pemain mengarahkan kamera ke objek ini.</summary>
    string Prompt { get; }

    bool CanInteract { get; }

    void Interact(GameObject interactor);
}
