using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using TrustSystem;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>One-shot editor automation for the Trust NPC encounter demo.</summary>
public static class TrustSystemDemoBuilder
{
    private const string ScenePath = "Assets/_Project/Scenes/TrustSystem_Demo.unity";
    private const string ActionPath = "Assets/_Project/Input/PlayerControls.inputactions";
    private const string ItemPrefabPath = "Assets/_Project/Prefabs/UI/ItemButton.prefab";
    private static readonly Color Gold = new Color(0.78f, 0.61f, 0.30f);
    private static readonly Color Panel = new Color(0.105f, 0.115f, 0.125f, 0.98f);
    private static readonly Color PanelLight = new Color(0.16f, 0.17f, 0.18f, 1f);
    private static readonly Color TextColor = new Color(0.94f, 0.91f, 0.84f);

    [MenuItem("Tools/Trust System/Build Demo Scene")]
    public static void Build()
    {
        try
        {
            EnsureFolders();
            EnsureInputAsset();
            TrustEncounterData npcData = CreateNpcData();
            TrustItemData[] items = CreateItems();
            Button itemPrefab = CreateItemPrefab();
            BuildScene(npcData, items, itemPrefab);
            ConfigureBuildScenes();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("TrustSystem_Demo created and saved successfully.");
        }
        catch (Exception ex)
        {
            Debug.LogError("Trust demo build failed: " + ex);
            throw;
        }
    }

    private static void EnsureFolders()
    {
        string[] folders = {
            "Assets/_Project", "Assets/_Project/Input", "Assets/_Project/Scenes",
            "Assets/_Project/Prefabs", "Assets/_Project/Prefabs/UI", "Assets/_Project/Data",
            "Assets/_Project/Data/NPC", "Assets/_Project/Data/Items", "Assets/Editor"
        };
        foreach (string folder in folders)
        {
            if (AssetDatabase.IsValidFolder(folder)) continue;
            string parent = Path.GetDirectoryName(folder).Replace('\\', '/');
            string name = Path.GetFileName(folder);
            if (!AssetDatabase.IsValidFolder(parent)) Directory.CreateDirectory(parent);
            AssetDatabase.CreateFolder(parent, name);
        }
    }

    private static void EnsureInputAsset()
    {
        const string oldPath = "Assets/PlayerControls.inputactions";
        if (!File.Exists(ActionPath) && File.Exists(oldPath))
        {
            string error = AssetDatabase.MoveAsset(oldPath, ActionPath);
            if (!string.IsNullOrEmpty(error)) throw new IOException(error);
        }
        if (!File.Exists(ActionPath)) throw new FileNotFoundException("PlayerControls.inputactions was not found.", ActionPath);
        AssetDatabase.ImportAsset(ActionPath, ImportAssetOptions.ForceUpdate);
    }

    private static TrustEncounterData CreateNpcData()
    {
        const string path = "Assets/_Project/Data/NPC/TD_NPC_Penjaga.asset";
        var data = AssetDatabase.LoadAssetAtPath<TrustEncounterData>(path);
        if (data == null)
        {
            data = ScriptableObject.CreateInstance<TrustEncounterData>();
            AssetDatabase.CreateAsset(data, path);
        }
        var so = new SerializedObject(data);
        so.FindProperty("npcName").stringValue = "Penjaga";
        so.FindProperty("maxTurns").intValue = 5;
        so.FindProperty("targetResonance").intValue = 10;
        so.FindProperty("clueChance").floatValue = 1f;
        var pool = so.FindProperty("moodPool");
        pool.arraySize = 4;
        SetMood(pool.GetArrayElementAtIndex(0), 0, 3, 3);
        SetMood(pool.GetArrayElementAtIndex(1), 1, 1, 2);
        SetMood(pool.GetArrayElementAtIndex(2), 2, 0, 0);
        SetMood(pool.GetArrayElementAtIndex(3), 3, -2, -2);
        so.FindProperty("introDescription").stringValue = "Gerbang batu tua berdiri di belakang penjaga. Ia memeriksa jalan dan sesekali melirikmu, tetap waspada namun tidak tergesa-gesa.";
        so.FindProperty("introDialogue").stringValue = "Berhenti dulu. Gerbang ini hanya kubuka untuk orang yang bisa kupercaya. Tunjukkan niatmu.";
        so.FindProperty("winDialogue").stringValue = "Baik. Aku percaya padamu. Silakan lewat, dan jaga dirimu di perjalanan.";
        so.FindProperty("loseDialogue").stringValue = "Belum. Sikapmu belum meyakinkanku. Coba lagi kalau sudah siap.";
        so.FindProperty("noClueText").stringValue = "Penjaga menahan ekspresinya; belum ada petunjuk yang jelas.";

        string[][] likes = {
            new[] { "Penjaga mengangguk kecil saat kamu memperhatikan keadaan sekitar." },
            new[] { "Saat kamu menyebut jalur patroli, penjaga tampak tertarik." },
            new[] { "Penjaga tampak menghargai bantuan nyata yang kamu tawarkan." },
            new[] { "Penjaga sedikit rileks ketika kamu memberinya waktu untuk berpikir." }
        };
        string[][] rejects = {
            new[] { "Penjaga tampak risih ketika kamu mengamatinya terlalu dekat." },
            new[] { "Penjaga mengerutkan dahi, seolah penjelasanmu tidak meyakinkan." },
            new[] { "Penjaga mundur saat kamu bergerak tanpa meminta izin." },
            new[] { "Penjaga mengetuk gagang tombaknya, tak sabar dengan diammu." }
        };
        string[] names = { "Observation", "Knowledge", "Action", "Silence" };
        var hints = so.FindProperty("hints");
        hints.arraySize = 4;
        for (int i = 0; i < 4; i++)
        {
            var hint = hints.GetArrayElementAtIndex(i);
            hint.FindPropertyRelative("approach").enumValueIndex = i;
            SetStrings(hint.FindPropertyRelative("likeLines"), likes[i]);
            SetStrings(hint.FindPropertyRelative("rejectLines"), rejects[i]);
        }
        SetStrings(so.FindProperty("veryLikeReactions"), new[] { "Penjaga tersenyum tipis. “Kau peka juga.”", "“Itu pilihan yang tepat. Terima kasih sudah memperhatikan.”" });
        SetStrings(so.FindProperty("likeReactions"), new[] { "“Masuk akal. Aku bisa menghargai itu.”", "Penjaga mengangguk, sedikit lebih santai." });
        SetStrings(so.FindProperty("neutralReactions"), new[] { "“Begitu rupanya.”", "Penjaga mendengarkan tanpa banyak bereaksi." });
        SetStrings(so.FindProperty("rejectReactions"), new[] { "“Jangan bertindak gegabah di gerbangku.”", "Penjaga menghela napas dan kembali bersikap waspada." });
        so.ApplyModifiedPropertiesWithoutUndo();
        EditorUtility.SetDirty(data);
        return data;
    }

    private static void SetMood(SerializedProperty rule, int mood, int min, int max)
    {
        rule.FindPropertyRelative("mood").enumValueIndex = mood;
        rule.FindPropertyRelative("min").intValue = min;
        rule.FindPropertyRelative("max").intValue = max;
    }

    private static void SetStrings(SerializedProperty property, string[] values)
    {
        property.arraySize = values.Length;
        for (int i = 0; i < values.Length; i++) property.GetArrayElementAtIndex(i).stringValue = values[i];
    }

    private static TrustItemData[] CreateItems()
    {
        string[] files = { "Item_ExtraTurn", "Item_RerollMood", "Item_Shield" };
        string[] names = { "Tambahan Giliran", "Ulang Petunjuk", "Perisai Kepercayaan" };
        string[] descriptions = {
            "Memberi satu giliran tambahan tanpa menghabiskan giliran saat ini.",
            "Mengacak ulang suasana hati penjaga dan memperbarui petunjuk.",
            "Menahan satu aksi yang seharusnya mengurangi resonansi."
        };
        TrustItemData[] assets = new TrustItemData[3];
        for (int i = 0; i < assets.Length; i++)
        {
            string path = "Assets/_Project/Data/Items/" + files[i] + ".asset";
            assets[i] = AssetDatabase.LoadAssetAtPath<TrustItemData>(path);
            if (assets[i] == null)
            {
                assets[i] = ScriptableObject.CreateInstance<TrustItemData>();
                AssetDatabase.CreateAsset(assets[i], path);
            }
            var so = new SerializedObject(assets[i]);
            so.FindProperty("displayName").stringValue = names[i];
            so.FindProperty("description").stringValue = descriptions[i];
            so.FindProperty("effect").enumValueIndex = i;
            so.FindProperty("icon").objectReferenceValue = null;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(assets[i]);
        }
        return assets;
    }

    private static Button CreateItemPrefab()
    {
        var existing = AssetDatabase.LoadAssetAtPath<GameObject>(ItemPrefabPath);
        if (existing != null) return existing.GetComponent<Button>();
        GameObject root = CreateUiObject("ItemButton", null, new Vector2(210, 54), PanelLight);
        var button = root.AddComponent<Button>();
        StyleButton(button, Gold);
        var label = CreateText("Label", root.transform, "Item", 19, TextAlignmentOptions.Center);
        Stretch(label.rectTransform, 12, 4, 12, 4);
        GameObject savedPrefab = PrefabUtility.SaveAsPrefabAsset(root, ItemPrefabPath);
        UnityEngine.Object.DestroyImmediate(root);
        return savedPrefab.GetComponent<Button>();
    }

    private static void BuildScene(TrustEncounterData data, TrustItemData[] items, Button itemPrefab)
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "TrustSystem_Demo";

        var environment = new GameObject("Environment");
        var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = "Floor"; floor.transform.SetParent(environment.transform);
        floor.transform.position = new Vector3(0, -0.2f, 2.5f); floor.transform.localScale = new Vector3(14, 0.4f, 18);
        floor.GetComponent<Renderer>().sharedMaterial = MakeMaterial("M_Floor", new Color(.22f, .25f, .24f));
        var decorations = new GameObject("Decorations"); decorations.transform.SetParent(environment.transform);
        AddCube("GatePost_Left", decorations.transform, new Vector3(-2, 1.7f, 4.8f), new Vector3(.55f, 3.4f, .55f), new Color(.32f, .29f, .25f));
        AddCube("GatePost_Right", decorations.transform, new Vector3(2, 1.7f, 4.8f), new Vector3(.55f, 3.4f, .55f), new Color(.32f, .29f, .25f));
        AddCube("GateBeam", decorations.transform, new Vector3(0, 3.2f, 4.8f), new Vector3(4.5f, .45f, .55f), new Color(.4f, .34f, .25f));
        var lightRoot = new GameObject("Lighting");
        var light = lightRoot.AddComponent<Light>(); light.type = LightType.Directional; light.intensity = 1.15f;
        lightRoot.transform.rotation = Quaternion.Euler(48, -30, 0);
        RenderSettings.ambientLight = new Color(.52f, .52f, .55f);

        var player = new GameObject("Player"); player.transform.position = new Vector3(0, 0, -1.2f);
        var characterController = player.AddComponent<CharacterController>();
        characterController.height = 1.8f;
        characterController.radius = .3f;
        characterController.center = new Vector3(0, .9f, 0);
        player.AddComponent<PlayerInputReader>();
        player.AddComponent<PlayerMovement>();
        var pivot = new GameObject("CameraPivot").transform; pivot.SetParent(player.transform, false); pivot.localPosition = new Vector3(0, 1.6f, 0);
        var cameraGo = new GameObject("Main Camera"); cameraGo.tag = "MainCamera"; cameraGo.transform.SetParent(pivot, false);
        cameraGo.AddComponent<Camera>(); cameraGo.AddComponent<AudioListener>();
        var look = player.AddComponent<PlayerLook>();
        SetObject(look, "cameraPivot", pivot); SetFloat(look, "sensitivity", .1f); SetFloat(look, "maxPitch", 85f);
        var interactor = player.AddComponent<PlayerInteractor>();
        SetObject(interactor, "viewOrigin", cameraGo.transform); SetFloat(interactor, "interactDistance", 3f);
        SetLayerMask(interactor, "interactMask", ~0);
        var inventory = player.AddComponent<PlayerInventory>();
        var inventorySo = new SerializedObject(inventory); var starting = inventorySo.FindProperty("startingItems"); starting.arraySize = items.Length;
        for (int i = 0; i < items.Length; i++) starting.GetArrayElementAtIndex(i).objectReferenceValue = items[i];
        inventorySo.ApplyModifiedPropertiesWithoutUndo();

        var npc = new GameObject("NPC_Penjaga"); npc.transform.position = new Vector3(0, 0, 2.1f);
        var capsule = npc.AddComponent<CapsuleCollider>(); capsule.height = 2f; capsule.radius = .42f; capsule.center = new Vector3(0, 1, 0); capsule.isTrigger = false;
        var visual = GameObject.CreatePrimitive(PrimitiveType.Capsule); visual.name = "Visual"; visual.transform.SetParent(npc.transform, false);
        visual.transform.localPosition = new Vector3(0, 1, 0); visual.transform.localScale = new Vector3(.8f, 1, .8f); UnityEngine.Object.DestroyImmediate(visual.GetComponent<Collider>());
        visual.GetComponent<Renderer>().sharedMaterial = MakeMaterial("M_NPC", new Color(.42f, .29f, .2f));
        var componentGroup = new GameObject("Components"); componentGroup.transform.SetParent(npc.transform, false);

        Canvas canvas = CreateCanvas();
        var prompt = CreatePrompt(canvas.transform);
        SetObject(interactor, "promptRoot", prompt.transform.parent.gameObject); SetObject(interactor, "promptLabel", prompt);
        var uiObjects = CreateEncounterUI(canvas.transform, itemPrefab);
        var trustUi = canvas.gameObject.AddComponent<TrustEncounterUI>();
        ConfigureEncounterUi(trustUi, uiObjects, itemPrefab);
        var trustNpc = npc.AddComponent<TrustNpc>();
        var npcSo = new SerializedObject(trustNpc);
        npcSo.FindProperty("data").objectReferenceValue = data;
        npcSo.FindProperty("ui").objectReferenceValue = trustUi;
        npcSo.FindProperty("resultDelay").floatValue = 1.2f;
        npcSo.ApplyModifiedPropertiesWithoutUndo();

        var eventSystem = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
        var module = eventSystem.GetComponent<InputSystemUIInputModule>();
        MethodInfo assign = typeof(InputSystemUIInputModule).GetMethod("AssignDefaultActions", BindingFlags.Public | BindingFlags.Instance);
        if (assign != null) assign.Invoke(module, null);

        EditorSceneManager.SaveScene(scene, ScenePath);
        Selection.activeGameObject = player;
    }

    private class UiRefs
    {
        public GameObject root, resultPanel;
        public TMP_Text npcName, description, dialogue, resonance, turns, result;
        public RectTransform items;
        public Button retry, close;
        public Button[] approaches;
        public TMP_Text[] approachLabels;
    }

    private static Canvas CreateCanvas()
    {
        var go = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = go.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = go.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080); scaler.matchWidthOrHeight = .5f;
        return canvas;
    }

    private static TMP_Text CreatePrompt(Transform parent)
    {
        var root = CreateUiObject("PromptRoot", parent, new Vector2(620, 60), new Color(.06f, .065f, .07f, .88f));
        Place(root.GetComponent<RectTransform>(), new Vector2(.5f, .06f), new Vector2(.5f, .06f), new Vector2(620, 60), new Vector2(0, 0));
        var text = CreateText("PromptText", root.transform, "[E] Bicara dengan Penjaga", 25, TextAlignmentOptions.Center);
        Stretch(text.rectTransform, 18, 6, 18, 6);
        root.SetActive(false);
        return text;
    }

    private static UiRefs CreateEncounterUI(Transform parent, Button itemPrefab)
    {
        var r = new UiRefs();
        r.root = new GameObject("TrustEncounterRoot", typeof(RectTransform)); r.root.transform.SetParent(parent, false);
        Stretch(r.root.GetComponent<RectTransform>(), 0, 0, 0, 0);
        var dim = CreateUiObject("DimBackground", r.root.transform, Vector2.zero, new Color(0, 0, 0, .72f));
        Stretch(dim.GetComponent<RectTransform>(), 0, 0, 0, 0);
        var panel = CreateUiObject("EncounterPanel", r.root.transform, new Vector2(1000, 800), Panel);
        Place(panel.GetComponent<RectTransform>(), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(1000, 800), Vector2.zero);
        var vertical = panel.AddComponent<VerticalLayoutGroup>(); vertical.padding = new RectOffset(34, 34, 28, 28); vertical.spacing = 16;
        vertical.childControlWidth = true; vertical.childControlHeight = false; vertical.childForceExpandWidth = true; vertical.childForceExpandHeight = false;
        var header = CreateUiObject("Header", panel.transform, new Vector2(1, 76), PanelLight);
        header.AddComponent<HorizontalLayoutGroup>().padding = new RectOffset(22, 22, 12, 12);
        header.GetComponent<HorizontalLayoutGroup>().spacing = 20;
        r.npcName = CreateText("NPCNameText", header.transform, "Penjaga", 32, TextAlignmentOptions.Left);
        r.npcName.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1;
        var status = CreateUiObject("StatusPanel", header.transform, new Vector2(420, 1), Panel);
        status.AddComponent<HorizontalLayoutGroup>().spacing = 24;
        r.resonance = CreateText("ResonanceText", status.transform, "Resonansi 0 / 10", 20, TextAlignmentOptions.Center);
        r.turns = CreateText("TurnsText", status.transform, "Giliran 5", 20, TextAlignmentOptions.Center);
        r.resonance.gameObject.AddComponent<LayoutElement>().preferredWidth = 205;
        r.turns.gameObject.AddComponent<LayoutElement>().preferredWidth = 180;
        var main = CreateUiObject("MainContent", panel.transform, new Vector2(1, 216), Panel);
        main.AddComponent<VerticalLayoutGroup>().spacing = 12;
        var descPanel = CreateUiObject("DescriptionPanel", main.transform, new Vector2(1, 106), new Color(.13f, .14f, .145f));
        r.description = CreateText("DescriptionText", descPanel.transform, "Petunjuk bahasa tubuh penjaga muncul di sini.", 22, TextAlignmentOptions.TopLeft);
        Stretch(r.description.rectTransform, 22, 15, 22, 15);
        var dialoguePanel = CreateUiObject("DialoguePanel", main.transform, new Vector2(1, 92), new Color(.085f, .09f, .095f));
        r.dialogue = CreateText("DialogueText", dialoguePanel.transform, "Dialog penjaga muncul di sini.", 21, TextAlignmentOptions.TopLeft);
        Stretch(r.dialogue.rectTransform, 22, 14, 22, 14);
        var approachPanel = CreateUiObject("ApproachPanel", panel.transform, new Vector2(1, 152), Panel);
        var grid = approachPanel.AddComponent<GridLayoutGroup>(); grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount; grid.constraintCount = 2;
        grid.cellSize = new Vector2(440, 64); grid.spacing = new Vector2(18, 12); grid.padding = new RectOffset(0, 0, 2, 2);
        string[] buttons = { "OBSButton", "KNOButton", "ACTButton", "SILButton" };
        r.approaches = new Button[4]; r.approachLabels = new TMP_Text[4];
        for (int i = 0; i < 4; i++)
        {
            var bgo = CreateUiObject(buttons[i], approachPanel.transform, new Vector2(440, 64), PanelLight);
            var b = bgo.AddComponent<Button>(); StyleButton(b, Gold); r.approaches[i] = b;
            r.approachLabels[i] = CreateText("Label", bgo.transform, new[] { "[OBS] Amati", "[KNO] Pengetahuan", "[ACT] Tindakan", "[SIL] Diam" }[i], 21, TextAlignmentOptions.Center);
            Stretch(r.approachLabels[i].rectTransform, 10, 4, 10, 4);
        }
        var itemPanel = CreateUiObject("ItemPanel", panel.transform, new Vector2(1, 92), Panel);
        itemPanel.AddComponent<HorizontalLayoutGroup>().spacing = 14;
        var itemTitle = CreateText("ItemTitle", itemPanel.transform, "Perlengkapan", 20, TextAlignmentOptions.Left);
        itemTitle.gameObject.AddComponent<LayoutElement>().preferredWidth = 180;
        var itemContainer = new GameObject("ItemContainer", typeof(RectTransform)); itemContainer.transform.SetParent(itemPanel.transform, false);
        itemContainer.AddComponent<HorizontalLayoutGroup>().spacing = 10;
        itemContainer.GetComponent<HorizontalLayoutGroup>().childControlWidth = false;
        itemContainer.GetComponent<HorizontalLayoutGroup>().childControlHeight = true;
        itemContainer.AddComponent<LayoutElement>().flexibleWidth = 1;
        r.items = itemContainer.GetComponent<RectTransform>();
        var result = CreateUiObject("ResultPanel", r.root.transform, new Vector2(600, 290), new Color(.055f, .06f, .065f, .99f));
        Place(result.GetComponent<RectTransform>(), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(600, 290), Vector2.zero);
        r.resultPanel = result;
        var resultTitle = CreateText("ResultText", result.transform, "Hasil pertemuan", 28, TextAlignmentOptions.Center);
        Place(resultTitle.rectTransform, new Vector2(.05f, .53f), new Vector2(.95f, .9f), Vector2.zero, Vector2.zero);
        r.result = resultTitle;
        var retryGo = CreateButton("RetryButton", result.transform, "Coba Lagi", new Vector2(210, 55));
        var closeGo = CreateButton("CloseButton", result.transform, "Tutup", new Vector2(210, 55));
        Place(retryGo.GetComponent<RectTransform>(), new Vector2(.12f, .12f), new Vector2(.48f, .36f), Vector2.zero, Vector2.zero);
        Place(closeGo.GetComponent<RectTransform>(), new Vector2(.52f, .12f), new Vector2(.88f, .36f), Vector2.zero, Vector2.zero);
        r.retry = retryGo.GetComponent<Button>(); r.close = closeGo.GetComponent<Button>();
        r.resultPanel.SetActive(false); r.root.SetActive(false);
        return r;
    }

    private static void ConfigureEncounterUi(TrustEncounterUI ui, UiRefs r, Button itemPrefab)
    {
        var so = new SerializedObject(ui);
        so.FindProperty("root").objectReferenceValue = r.root;
        so.FindProperty("npcNameLabel").objectReferenceValue = r.npcName;
        so.FindProperty("descriptionLabel").objectReferenceValue = r.description;
        so.FindProperty("dialogueLabel").objectReferenceValue = r.dialogue;
        so.FindProperty("resonanceLabel").objectReferenceValue = r.resonance;
        so.FindProperty("turnsLabel").objectReferenceValue = r.turns;
        var buttons = so.FindProperty("approachButtons"); buttons.arraySize = 4;
        for (int i = 0; i < 4; i++)
        {
            var entry = buttons.GetArrayElementAtIndex(i);
            entry.FindPropertyRelative("approach").enumValueIndex = i;
            entry.FindPropertyRelative("button").objectReferenceValue = r.approaches[i];
            entry.FindPropertyRelative("label").objectReferenceValue = r.approachLabels[i];
        }
        so.FindProperty("itemContainer").objectReferenceValue = r.items;
        so.FindProperty("itemButtonPrefab").objectReferenceValue = itemPrefab;
        so.FindProperty("resultPanel").objectReferenceValue = r.resultPanel;
        so.FindProperty("resultLabel").objectReferenceValue = r.result;
        so.FindProperty("retryButton").objectReferenceValue = r.retry;
        so.FindProperty("closeButton").objectReferenceValue = r.close;
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static GameObject CreateButton(string name, Transform parent, string label, Vector2 size)
    {
        var go = CreateUiObject(name, parent, size, PanelLight);
        var button = go.AddComponent<Button>(); StyleButton(button, Gold);
        var text = CreateText("Label", go.transform, label, 21, TextAlignmentOptions.Center); Stretch(text.rectTransform, 8, 5, 8, 5);
        return go;
    }

    private static void StyleButton(Button button, Color accent)
    {
        button.transition = Selectable.Transition.ColorTint;
        var colors = button.colors; colors.normalColor = PanelLight; colors.highlightedColor = new Color(.28f, .25f, .19f);
        colors.pressedColor = accent * .72f; colors.selectedColor = new Color(.24f, .22f, .18f); colors.disabledColor = new Color(.13f, .13f, .13f, .55f);
        colors.colorMultiplier = 1; colors.fadeDuration = .12f; button.colors = colors;
        var target = button.targetGraphic as Image; if (target != null) target.color = PanelLight;
    }

    private static GameObject CreateUiObject(string name, Transform parent, Vector2 size, Color color)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        if (parent != null) go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>(); rect.sizeDelta = size;
        var image = go.GetComponent<Image>(); image.color = color; image.raycastTarget = true;
        return go;
    }

    private static TMP_Text CreateText(string name, Transform parent, string value, float size, TextAlignmentOptions alignment)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI)); go.transform.SetParent(parent, false);
        var text = go.GetComponent<TextMeshProUGUI>(); text.text = value; text.fontSize = size; text.color = TextColor;
        text.alignment = alignment; text.textWrappingMode = TextWrappingModes.Normal; text.raycastTarget = false;
        var font = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset");
        if (font != null) text.font = font;
        return text;
    }

    private static void Place(RectTransform rect, Vector2 anchorMin, Vector2 anchorMax, Vector2 size, Vector2 position)
    {
        rect.anchorMin = anchorMin; rect.anchorMax = anchorMax; rect.sizeDelta = size; rect.anchoredPosition = position;
    }

    private static void Stretch(RectTransform rect, float left, float bottom, float right, float top)
    {
        rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one;
        rect.offsetMin = new Vector2(left, bottom); rect.offsetMax = new Vector2(-right, -top);
    }

    private static void AddCube(string name, Transform parent, Vector3 position, Vector3 scale, Color color)
    {
        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube); cube.name = name; cube.transform.SetParent(parent, true);
        cube.transform.position = position; cube.transform.localScale = scale; cube.GetComponent<Renderer>().sharedMaterial = MakeMaterial("M_" + name, color);
    }

    private static Material MakeMaterial(string name, Color color)
    {
        string path = "Assets/_Project/" + name + ".mat";
        var mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            mat = new Material(shader); AssetDatabase.CreateAsset(mat, path);
        }
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
        if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
        EditorUtility.SetDirty(mat); return mat;
    }

    private static void SetObject(UnityEngine.Object target, string field, UnityEngine.Object value)
    {
        var so = new SerializedObject(target); so.FindProperty(field).objectReferenceValue = value; so.ApplyModifiedPropertiesWithoutUndo();
    }
    private static void SetFloat(UnityEngine.Object target, string field, float value)
    {
        var so = new SerializedObject(target); so.FindProperty(field).floatValue = value; so.ApplyModifiedPropertiesWithoutUndo();
    }
    private static void SetLayerMask(UnityEngine.Object target, string field, int value)
    {
        var so = new SerializedObject(target); so.FindProperty(field).intValue = value; so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void ConfigureBuildScenes()
    {
        var scenes = EditorBuildSettings.scenes.ToList();
        if (!scenes.Any(s => s.path == ScenePath)) scenes.Add(new EditorBuildSettingsScene(ScenePath, true));
        EditorBuildSettings.scenes = scenes.ToArray();
    }
}
