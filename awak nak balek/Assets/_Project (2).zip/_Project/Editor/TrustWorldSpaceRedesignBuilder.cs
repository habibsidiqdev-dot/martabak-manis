using System;
using System.Linq;
using System.Reflection;
using TMPro;
using TrustSystem;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

/// <summary>Applies the world-space Trust encounter presentation to the existing demo scene in place.</summary>
public static class TrustWorldSpaceRedesignBuilder
{
    private const string ScenePath = "Assets/_Project/Scenes/TrustSystem_Demo.unity";
    private static readonly Color Ink = new Color(.035f, .043f, .052f, .96f);
    private static readonly Color Panel = new Color(.055f, .067f, .077f, .93f);
    private static readonly Color PanelRaised = new Color(.09f, .105f, .115f, .97f);
    private static readonly Color Gold = new Color(.78f, .59f, .30f, 1f);
    private static readonly Color GoldSoft = new Color(.66f, .48f, .24f, .42f);
    private static readonly Color Paper = new Color(.94f, .92f, .86f, 1f);
    private static TMP_FontAsset font;

    [MenuItem("Tools/Trust System/Apply World Space Redesign")]
    public static void Apply()
    {
        if (EditorApplication.isPlaying)
        {
            Debug.LogError("Stop Play Mode before applying the Trust World Space redesign.");
            return;
        }

        var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        if (!scene.IsValid() || scene.path != ScenePath)
        {
            scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
        }

        GameObject player = GameObject.Find("Player");
        GameObject npc = GameObject.Find("NPC_Penjaga");
        GameObject oldCanvas = GameObject.Find("EncounterHUDCanvas") ?? GameObject.Find("Canvas");
        if (player == null || npc == null || oldCanvas == null)
        {
            Debug.LogError("TrustSystem_Demo must contain Player, NPC_Penjaga, and its existing Canvas.");
            return;
        }

        Transform cameraTransform = player.transform.Find("CameraPivot/Main Camera");
        Camera mainCamera = cameraTransform != null ? cameraTransform.GetComponent<Camera>() : null;
        PlayerInteractor interactor = player.GetComponent<PlayerInteractor>();
        TrustNpc trustNpc = npc.GetComponent<TrustNpc>();
        if (mainCamera == null || interactor == null || trustNpc == null)
        {
            Debug.LogError("Demo Player camera/interactor or NPC TrustNpc component is missing.");
            return;
        }

        font = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset");
        Canvas hudCanvas = oldCanvas.GetComponent<Canvas>() ?? oldCanvas.AddComponent<Canvas>();
        TrustEncounterUI ui = oldCanvas.GetComponent<TrustEncounterUI>() ?? oldCanvas.AddComponent<TrustEncounterUI>();
        GameObject oldPromptRoot = UnityEngine.Resources.FindObjectsOfTypeAll<GameObject>()
            .FirstOrDefault(o => o.scene == scene && o.name == "PromptRoot");
        if (oldPromptRoot != null) UnityEngine.Object.DestroyImmediate(oldPromptRoot);
        GameObject promptRoot = CreatePrompt(mainCamera, out TMP_Text promptText);
        ConfigureHudCanvas(oldCanvas, hudCanvas, mainCamera);
        ClearChildren(oldCanvas.transform);
        UiRefs refs = BuildHud(oldCanvas.transform);

        Transform dialogueAnchor = npc.transform.Find("DialogueAnchor");
        if (dialogueAnchor == null)
        {
            var anchorObject = new GameObject("DialogueAnchor");
            dialogueAnchor = anchorObject.transform;
            dialogueAnchor.SetParent(npc.transform, false);
        }
        dialogueAnchor.localPosition = new Vector3(0f, 2.08f, 0f);
        dialogueAnchor.localRotation = Quaternion.identity;
        dialogueAnchor.localScale = Vector3.one;
        ClearChildren(dialogueAnchor);
        GameObject dialogueRoot = BuildDialogueCanvas(dialogueAnchor, mainCamera, out TMP_Text nameText, out TMP_Text dialogueText);
        refs.nameText = nameText;
        refs.dialogueText = dialogueText;
        ConfigureEncounterUI(ui, refs, dialogueRoot);
        ConfigureInteractor(interactor, promptRoot, promptText);
        ConfigureNpc(trustNpc, ui);
        ConfigureEventSystem(mainCamera);
        ConfigureItemPrefab();

        EditorUtility.SetDirty(ui);
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene);
        Debug.Log("Applied World Space Trust UI to existing TrustSystem_Demo scene.");
    }

    [MenuItem("Tools/Trust System/Validate World Space Redesign")]
    public static void Validate()
    {
        var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        var hud = GameObject.Find("EncounterHUDCanvas");
        var dialogue = GameObject.Find("NPCDialogueCanvas");
        var prompt = UnityEngine.Resources.FindObjectsOfTypeAll<GameObject>()
            .FirstOrDefault(o => o.scene == scene && o.name == "PromptRoot");
        var eventSystems = UnityEngine.Object.FindObjectsByType<EventSystem>(FindObjectsSortMode.None);
        var modules = UnityEngine.Object.FindObjectsByType<InputSystemUIInputModule>(FindObjectsSortMode.None);
        bool hudOk = hud != null && hud.GetComponent<Canvas>()?.renderMode == RenderMode.WorldSpace &&
                     hud.GetComponent<TrustEncounterUI>() != null && hud.GetComponent<GraphicRaycaster>() != null;
        bool dialogueOk = dialogue != null && dialogue.GetComponent<Canvas>()?.renderMode == RenderMode.WorldSpace &&
                          dialogue.GetComponent<WorldSpaceBillboard>() != null && dialogue.GetComponent<GraphicRaycaster>() != null;
        bool promptOk = prompt != null && prompt.GetComponent<Canvas>()?.renderMode == RenderMode.WorldSpace &&
                        prompt.GetComponent<WorldSpaceBillboard>() != null;
        Debug.Log($"TRUST_WORLDSPACE_VALIDATION scene={scene.path} hud={hudOk} dialogue={dialogueOk} prompt={promptOk} " +
                  $"eventSystems={eventSystems.Length} inputModules={modules.Length} dirty={scene.isDirty}");
        if (!hudOk || !dialogueOk || !promptOk || eventSystems.Length != 1 || modules.Length != 1)
            Debug.LogError("World Space Trust UI validation failed. Inspect references and Canvas/EventSystem setup.");
    }

    private sealed class UiRefs
    {
        public GameObject hudRoot;
        public TMP_Text nameText, hintText, dialogueText, resonanceText, turnsText, resultText;
        public RectTransform itemContainer;
        public Button[] approachButtons = new Button[4];
        public TMP_Text[] approachLabels = new TMP_Text[4];
        public GameObject resultPanel, dialogueRoot;
        public Button retryButton, closeButton;
    }

    private static void ConfigureHudCanvas(GameObject go, Canvas canvas, Camera camera)
    {
        go.name = "EncounterHUDCanvas";
        go.transform.SetParent(camera.transform, false);
        go.transform.localPosition = new Vector3(0f, 0f, 1.02f);
        go.transform.localRotation = Quaternion.identity;
        go.transform.localScale = Vector3.one * .001f;
        var rect = go.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(1920f, 1080f);
        canvas.renderMode = RenderMode.WorldSpace;
        canvas.worldCamera = camera;
        canvas.pixelPerfect = false;
        canvas.overrideSorting = true;
        canvas.sortingOrder = 20;

        var scaler = go.GetComponent<CanvasScaler>() ?? go.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
        scaler.scaleFactor = 1f;
        scaler.referencePixelsPerUnit = 100f;
        scaler.dynamicPixelsPerUnit = 1f;
        var raycaster = go.GetComponent<GraphicRaycaster>() ?? go.AddComponent<GraphicRaycaster>();
        raycaster.ignoreReversedGraphics = false;
    }

    private static GameObject CreatePrompt(Camera camera, out TMP_Text text)
    {
        var prompt = new GameObject("PromptRoot", typeof(RectTransform));
        var canvas = prompt.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;
        canvas.worldCamera = camera;
        canvas.overrideSorting = true;
        canvas.sortingOrder = 30;
        prompt.AddComponent<CanvasRenderer>();
        prompt.AddComponent<Image>();
        var rect = prompt.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(470f, 72f);
        rect.localScale = Vector3.one * .001f;
        var raycaster = prompt.GetComponent<GraphicRaycaster>() ?? prompt.AddComponent<GraphicRaycaster>();
        raycaster.ignoreReversedGraphics = false;
        var background = prompt.GetComponent<Image>();
        background.color = new Color(.025f, .035f, .043f, .92f);
        background.raycastTarget = false;
        var strip = CreateImage("Accent", prompt.transform, Gold);
        Stretch(strip.GetComponent<RectTransform>(), new Vector2(.025f, .15f), new Vector2(.035f, .85f));

        text = CreateText("PromptText", prompt.transform, "[E]  BICARA", 28f, TextAlignmentOptions.Center);
        text.name = "PromptText";
        text.text = "[E]  BICARA";
        text.fontSize = 28f;
        text.color = Paper;
        text.alignment = TextAlignmentOptions.Center;
        text.raycastTarget = false;
        Stretch(text.rectTransform, new Vector2(.07f, .08f), new Vector2(.96f, .92f));
        prompt.AddComponent<WorldSpaceBillboard>().SetCamera(camera);
        prompt.SetActive(false);
        return prompt;
    }

    private static UiRefs BuildHud(Transform canvas)
    {
        var r = new UiRefs();
        r.hudRoot = CreateRect("EncounterHUDRoot", canvas);
        Stretch(r.hudRoot.GetComponent<RectTransform>(), Vector2.zero, Vector2.one);
        var dim = CreateImage("DimBackground", r.hudRoot.transform, new Color(.01f, .015f, .02f, .20f));
        Stretch(dim.GetComponent<RectTransform>(), Vector2.zero, Vector2.one);
        dim.GetComponent<Image>().raycastTarget = true;

        var eventPanel = CreatePanel("EventDescriptionPanel", r.hudRoot.transform, Panel, GoldSoft);
        Stretch(eventPanel.GetComponent<RectTransform>(), new Vector2(.035f, .66f), new Vector2(.405f, .945f));
        CreateAccent(eventPanel.transform, Gold);
        var icon = CreatePanel("HintIcon", eventPanel.transform, PanelRaised, GoldSoft);
        Stretch(icon.GetComponent<RectTransform>(), new Vector2(.045f, .765f), new Vector2(.105f, .94f));
        CenterText(icon.transform, "Icon", "!", 26f, Gold, FontStyles.Bold);
        var title = CreateText("Header", eventPanel.transform, "DESKRIPSI KEJADIAN", 24f, TextAlignmentOptions.Left);
        title.fontStyle = FontStyles.Bold;
        title.color = Gold;
        Stretch(title.rectTransform, new Vector2(.13f, .765f), new Vector2(.96f, .94f));
        r.hintText = CreateText("HintText", eventPanel.transform, "Petunjuk bahasa tubuh akan muncul di sini.", 30f, TextAlignmentOptions.TopLeft);
        r.hintText.enableAutoSizing = true;
        r.hintText.fontSizeMin = 24f;
        r.hintText.fontSizeMax = 31f;
        Stretch(r.hintText.rectTransform, new Vector2(.055f, .20f), new Vector2(.95f, .72f));
        var hintIndicator = CreateText("HintIndicator", eventPanel.transform, "PETUNJUK AKTIF  •  AMATI REAKSINYA", 15f, TextAlignmentOptions.Left);
        hintIndicator.color = new Color(.72f, .74f, .71f, .9f);
        Stretch(hintIndicator.rectTransform, new Vector2(.055f, .055f), new Vector2(.95f, .16f));

        var status = CreatePanel("StatusPanel", r.hudRoot.transform, new Color(.035f, .045f, .055f, .90f), GoldSoft);
        Stretch(status.GetComponent<RectTransform>(), new Vector2(.64f, .925f), new Vector2(.965f, .985f));
        r.resonanceText = CreateText("ResonanceText", status.transform, "RESONANCE  00 / 10", 21f, TextAlignmentOptions.Left);
        r.resonanceText.fontStyle = FontStyles.Bold;
        Stretch(r.resonanceText.rectTransform, new Vector2(.055f, .05f), new Vector2(.54f, .95f));
        r.turnsText = CreateText("TurnsText", status.transform, "TURNS LEFT  05", 20f, TextAlignmentOptions.Right);
        r.turnsText.color = new Color(.85f, .86f, .84f, 1f);
        Stretch(r.turnsText.rectTransform, new Vector2(.55f, .05f), new Vector2(.96f, .95f));

        var choices = CreatePanel("ApproachChoicesPanel", r.hudRoot.transform, Panel, GoldSoft);
        Stretch(choices.GetComponent<RectTransform>(), new Vector2(.035f, .075f), new Vector2(.405f, .62f));
        CreateAccent(choices.transform, Gold);
        var choicesTitle = CreateText("ChoicesTitle", choices.transform, "PILIHAN PENDEKATAN", 22f, TextAlignmentOptions.Left);
        choicesTitle.color = Gold;
        choicesTitle.fontStyle = FontStyles.Bold;
        Stretch(choicesTitle.rectTransform, new Vector2(.055f, .875f), new Vector2(.95f, .97f));

        var list = CreateRect("ApproachList", choices.transform);
        Stretch(list.GetComponent<RectTransform>(), new Vector2(.045f, .235f), new Vector2(.955f, .855f));
        var layout = list.AddComponent<VerticalLayoutGroup>();
        layout.spacing = 10f;
        layout.padding = new RectOffset(0, 0, 0, 0);
        layout.childControlWidth = true;
        layout.childControlHeight = false;
        layout.childForceExpandWidth = true;
        layout.childForceExpandHeight = false;
        string[] names = { "OBSButton", "KNOButton", "ACTButton", "SILButton" };
        string[] codes = { "OBS", "KNO", "ACT", "SIL" };
        for (int i = 0; i < 4; i++)
        {
            var buttonObject = CreateButton(names[i], list.transform, PanelRaised, new Vector2(0f, 74f));
            var layoutElement = buttonObject.AddComponent<LayoutElement>();
            layoutElement.preferredHeight = 74f;
            layoutElement.minHeight = 66f;
            r.approachButtons[i] = buttonObject.GetComponent<Button>();
            var code = CreatePanel("Icon", buttonObject.transform, new Color(.12f, .12f, .105f, .95f), GoldSoft);
            Stretch(code.GetComponent<RectTransform>(), new Vector2(.025f, .14f), new Vector2(.115f, .86f));
            CenterText(code.transform, "Code", codes[i], 18f, Gold, FontStyles.Bold);
            r.approachLabels[i] = CreateText("Label", buttonObject.transform, "", 23f, TextAlignmentOptions.Left);
            r.approachLabels[i].enableAutoSizing = true;
            r.approachLabels[i].fontSizeMin = 19f;
            r.approachLabels[i].fontSizeMax = 24f;
            Stretch(r.approachLabels[i].rectTransform, new Vector2(.15f, .08f), new Vector2(.87f, .92f));
            var arrow = CreateText("Indicator", buttonObject.transform, "›", 32f, TextAlignmentOptions.Center);
            arrow.color = new Color(.72f, .67f, .55f, .82f);
            Stretch(arrow.rectTransform, new Vector2(.88f, .05f), new Vector2(.98f, .95f));
        }

        var itemPanel = CreatePanel("ItemPanel", choices.transform, new Color(.035f, .043f, .052f, .62f), new Color(0, 0, 0, 0));
        Stretch(itemPanel.GetComponent<RectTransform>(), new Vector2(.035f, .035f), new Vector2(.965f, .20f));
        var itemTitle = CreateText("ItemTitle", itemPanel.transform, "ITEMS", 17f, TextAlignmentOptions.Left);
        itemTitle.fontStyle = FontStyles.Bold;
        itemTitle.color = new Color(.79f, .78f, .72f, 1f);
        Stretch(itemTitle.rectTransform, new Vector2(.025f, .08f), new Vector2(.19f, .92f));
        var items = CreateRect("ItemContainer", itemPanel.transform);
        Stretch(items.GetComponent<RectTransform>(), new Vector2(.20f, .08f), new Vector2(.985f, .92f));
        var itemLayout = items.AddComponent<HorizontalLayoutGroup>();
        itemLayout.spacing = 8f;
        itemLayout.childControlWidth = false;
        itemLayout.childControlHeight = true;
        itemLayout.childForceExpandWidth = false;
        itemLayout.childForceExpandHeight = true;
        r.itemContainer = items.GetComponent<RectTransform>();

        r.resultPanel = CreatePanel("ResultPanel", r.hudRoot.transform, new Color(.035f, .043f, .052f, .985f), GoldSoft);
        Stretch(r.resultPanel.GetComponent<RectTransform>(), new Vector2(.345f, .34f), new Vector2(.655f, .66f));
        r.resultPanel.AddComponent<CanvasGroup>();
        CreateAccent(r.resultPanel.transform, Gold);
        var resultHeader = CreateText("ResultHeader", r.resultPanel.transform, "PERTEMUAN SELESAI", 21f, TextAlignmentOptions.Center);
        resultHeader.color = Gold;
        resultHeader.fontStyle = FontStyles.Bold;
        Stretch(resultHeader.rectTransform, new Vector2(.06f, .79f), new Vector2(.94f, .95f));
        r.resultText = CreateText("ResultText", r.resultPanel.transform, "Penjaga mempercayaimu.", 30f, TextAlignmentOptions.Center);
        r.resultText.enableAutoSizing = true;
        r.resultText.fontSizeMin = 23f;
        r.resultText.fontSizeMax = 31f;
        Stretch(r.resultText.rectTransform, new Vector2(.08f, .40f), new Vector2(.92f, .77f));
        r.retryButton = CreateButton("RetryButton", r.resultPanel.transform, PanelRaised, new Vector2(220f, 58f)).GetComponent<Button>();
        r.closeButton = CreateButton("CloseButton", r.resultPanel.transform, PanelRaised, new Vector2(220f, 58f)).GetComponent<Button>();
        var retryLabel = CreateText("Label", r.retryButton.transform, "Coba Lagi", 22f, TextAlignmentOptions.Center);
        Stretch(retryLabel.rectTransform, new Vector2(.04f, .05f), new Vector2(.96f, .95f));
        var closeLabel = CreateText("Label", r.closeButton.transform, "Tutup", 22f, TextAlignmentOptions.Center);
        Stretch(closeLabel.rectTransform, new Vector2(.04f, .05f), new Vector2(.96f, .95f));
        Stretch(r.retryButton.GetComponent<RectTransform>(), new Vector2(.10f, .11f), new Vector2(.48f, .32f));
        Stretch(r.closeButton.GetComponent<RectTransform>(), new Vector2(.52f, .11f), new Vector2(.90f, .32f));
        r.resultPanel.SetActive(false);
        r.hudRoot.SetActive(false);
        return r;
    }

    private static GameObject BuildDialogueCanvas(Transform anchor, Camera camera, out TMP_Text nameText, out TMP_Text dialogueText)
    {
        var canvasObject = CreateRect("NPCDialogueCanvas", anchor);
        canvasObject.transform.localPosition = new Vector3(0f, .31f, .03f);
        canvasObject.transform.localRotation = Quaternion.identity;
        canvasObject.transform.localScale = Vector3.one * .001f;
        var canvas = canvasObject.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;
        canvas.worldCamera = camera;
        canvas.overrideSorting = true;
        canvas.sortingOrder = 25;
        var rect = canvasObject.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(1000f, 280f);
        var scaler = canvasObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
        scaler.dynamicPixelsPerUnit = 1f;
        scaler.referencePixelsPerUnit = 100f;
        var raycaster = canvasObject.AddComponent<GraphicRaycaster>();
        raycaster.ignoreReversedGraphics = false;
        canvasObject.AddComponent<WorldSpaceBillboard>().SetCamera(camera);

        var root = CreateRect("NPCDialogueRoot", canvasObject.transform);
        Stretch(root.GetComponent<RectTransform>(), Vector2.zero, Vector2.one);
        root.AddComponent<CanvasGroup>();
        var panel = CreatePanel("NPCDialoguePanel", root.transform, new Color(.028f, .036f, .043f, .92f), GoldSoft);
        Stretch(panel.GetComponent<RectTransform>(), new Vector2(.015f, .04f), new Vector2(.985f, .96f));
        CreateAccent(panel.transform, Gold);
        nameText = CreateText("NPCNameText", panel.transform, "PENJAGA", 19f, TextAlignmentOptions.Left);
        nameText.fontStyle = FontStyles.Bold;
        nameText.color = Gold;
        Stretch(nameText.rectTransform, new Vector2(.055f, .70f), new Vector2(.94f, .92f));
        dialogueText = CreateText("DialogueText", panel.transform, "", 30f, TextAlignmentOptions.Left);
        dialogueText.enableAutoSizing = true;
        dialogueText.fontSizeMin = 22f;
        dialogueText.fontSizeMax = 31f;
        Stretch(dialogueText.rectTransform, new Vector2(.055f, .12f), new Vector2(.94f, .68f));
        root.SetActive(false);
        return root;
    }

    private static void ConfigureEncounterUI(TrustEncounterUI ui, UiRefs r, GameObject dialogueRoot)
    {
        var so = new SerializedObject(ui);
        so.FindProperty("root").objectReferenceValue = r.hudRoot;
        so.FindProperty("npcDialogueRoot").objectReferenceValue = dialogueRoot;
        so.FindProperty("npcNameLabel").objectReferenceValue = r.nameText;
        so.FindProperty("descriptionLabel").objectReferenceValue = r.hintText;
        so.FindProperty("dialogueLabel").objectReferenceValue = r.dialogueText;
        so.FindProperty("resonanceLabel").objectReferenceValue = r.resonanceText;
        so.FindProperty("turnsLabel").objectReferenceValue = r.turnsText;
        var buttons = so.FindProperty("approachButtons");
        buttons.arraySize = 4;
        for (int i = 0; i < 4; i++)
        {
            var entry = buttons.GetArrayElementAtIndex(i);
            entry.FindPropertyRelative("approach").enumValueIndex = i;
            entry.FindPropertyRelative("button").objectReferenceValue = r.approachButtons[i];
            entry.FindPropertyRelative("label").objectReferenceValue = r.approachLabels[i];
        }
        so.FindProperty("itemContainer").objectReferenceValue = r.itemContainer;
        so.FindProperty("itemButtonPrefab").objectReferenceValue = AssetDatabase.LoadAssetAtPath<Button>("Assets/_Project/Prefabs/UI/ItemButton.prefab");
        so.FindProperty("resultPanel").objectReferenceValue = r.resultPanel;
        so.FindProperty("resultLabel").objectReferenceValue = r.resultText;
        so.FindProperty("retryButton").objectReferenceValue = r.retryButton;
        so.FindProperty("closeButton").objectReferenceValue = r.closeButton;
        so.ApplyModifiedPropertiesWithoutUndo();
        EditorUtility.SetDirty(ui);
    }

    private static void ConfigureInteractor(PlayerInteractor interactor, GameObject prompt, TMP_Text label)
    {
        var so = new SerializedObject(interactor);
        so.FindProperty("promptRoot").objectReferenceValue = prompt;
        so.FindProperty("promptLabel").objectReferenceValue = label;
        so.ApplyModifiedPropertiesWithoutUndo();
        EditorUtility.SetDirty(interactor);
    }

    private static void ConfigureNpc(TrustNpc npc, TrustEncounterUI ui)
    {
        var so = new SerializedObject(npc);
        so.FindProperty("ui").objectReferenceValue = ui;
        so.ApplyModifiedPropertiesWithoutUndo();
        EditorUtility.SetDirty(npc);
    }

    private static void ConfigureEventSystem(Camera camera)
    {
        var systems = UnityEngine.Object.FindObjectsByType<EventSystem>(FindObjectsSortMode.None);
        EventSystem eventSystem = systems.FirstOrDefault();
        if (eventSystem == null) eventSystem = new GameObject("EventSystem").AddComponent<EventSystem>();
        foreach (var duplicate in systems.Skip(1)) UnityEngine.Object.DestroyImmediate(duplicate.gameObject);
        foreach (var legacy in eventSystem.GetComponents<StandaloneInputModule>()) UnityEngine.Object.DestroyImmediate(legacy);
        var module = eventSystem.GetComponent<InputSystemUIInputModule>() ?? eventSystem.gameObject.AddComponent<InputSystemUIInputModule>();
        if (module.actionsAsset == null)
        {
            MethodInfo assign = typeof(InputSystemUIInputModule).GetMethod("AssignDefaultActions", BindingFlags.Public | BindingFlags.Instance);
            assign?.Invoke(module, null);
        }
        EditorUtility.SetDirty(eventSystem);
    }

    private static void ConfigureItemPrefab()
    {
        const string path = "Assets/_Project/Prefabs/UI/ItemButton.prefab";
        var prefab = PrefabUtility.LoadPrefabContents(path);
        if (prefab == null) return;
        var rect = prefab.GetComponent<RectTransform>();
        if (rect != null) rect.sizeDelta = new Vector2(150f, 54f);
        var button = prefab.GetComponent<Button>();
        if (button != null)
        {
            button.transition = Selectable.Transition.ColorTint;
            var colors = button.colors;
            colors.normalColor = PanelRaised;
            colors.highlightedColor = new Color(.25f, .22f, .16f, 1f);
            colors.pressedColor = new Color(.42f, .32f, .18f, 1f);
            colors.selectedColor = new Color(.24f, .22f, .17f, 1f);
            colors.disabledColor = new Color(.12f, .13f, .14f, .55f);
            colors.fadeDuration = .12f;
            button.colors = colors;
        }
        var image = prefab.GetComponent<Image>();
        if (image != null) image.color = PanelRaised;
        var label = prefab.GetComponentInChildren<TMP_Text>(true);
        if (label != null)
        {
            label.font = font != null ? font : label.font;
            label.fontSize = 17f;
            label.enableAutoSizing = true;
            label.fontSizeMin = 13f;
            label.fontSizeMax = 18f;
            label.textWrappingMode = TextWrappingModes.Normal;
            label.alignment = TextAlignmentOptions.Center;
            label.margin = new Vector4(7f, 3f, 7f, 3f);
        }
        PrefabUtility.SaveAsPrefabAsset(prefab, path);
        PrefabUtility.UnloadPrefabContents(prefab);
    }

    private static void ClearChildren(Transform parent)
    {
        for (int i = parent.childCount - 1; i >= 0; i--)
            UnityEngine.Object.DestroyImmediate(parent.GetChild(i).gameObject);
    }

    private static GameObject CreateRect(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return go;
    }

    private static GameObject CreateImage(string name, Transform parent, Color color)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        go.transform.SetParent(parent, false);
        var image = go.GetComponent<Image>();
        image.color = color;
        image.raycastTarget = false;
        return go;
    }

    private static GameObject CreatePanel(string name, Transform parent, Color color, Color border)
    {
        var go = CreateImage(name, parent, border);
        var bg = CreateImage("Surface", go.transform, color);
        Stretch(bg.GetComponent<RectTransform>(), new Vector2(.003f, .012f), new Vector2(.997f, .988f));
        return go;
    }

    private static void CreateAccent(Transform parent, Color color)
    {
        var accent = CreateImage("Accent", parent, color);
        Stretch(accent.GetComponent<RectTransform>(), new Vector2(.008f, .055f), new Vector2(.014f, .945f));
    }

    private static GameObject CreateButton(string name, Transform parent, Color color, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>();
        rect.sizeDelta = size;
        var image = go.GetComponent<Image>();
        image.color = color;
        var button = go.GetComponent<Button>();
        button.targetGraphic = image;
        button.transition = Selectable.Transition.ColorTint;
        var colors = button.colors;
        colors.normalColor = color;
        colors.highlightedColor = new Color(.22f, .20f, .16f, .98f);
        colors.pressedColor = new Color(.40f, .30f, .17f, 1f);
        colors.selectedColor = new Color(.20f, .19f, .15f, 1f);
        colors.disabledColor = new Color(.10f, .11f, .12f, .58f);
        colors.fadeDuration = .12f;
        button.colors = colors;
        return go;
    }

    private static TMP_Text CreateText(string name, Transform parent, string value, float size, TextAlignmentOptions alignment)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
        go.transform.SetParent(parent, false);
        var text = go.GetComponent<TextMeshProUGUI>();
        text.text = value;
        text.font = font != null ? font : text.font;
        text.fontSize = size;
        text.color = Paper;
        text.alignment = alignment;
        text.textWrappingMode = TextWrappingModes.Normal;
        text.overflowMode = TextOverflowModes.Truncate;
        text.raycastTarget = false;
        return text;
    }

    private static TMP_Text CenterText(Transform parent, string name, string value, float size, Color color, FontStyles style = FontStyles.Normal)
    {
        var text = CreateText(name, parent, value, size, TextAlignmentOptions.Center);
        text.fontStyle = style;
        text.color = color;
        Stretch(text.rectTransform, new Vector2(.04f, .04f), new Vector2(.96f, .96f));
        return text;
    }

    private static void Stretch(RectTransform rect, Vector2 min, Vector2 max)
    {
        rect.anchorMin = min;
        rect.anchorMax = max;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }
}
