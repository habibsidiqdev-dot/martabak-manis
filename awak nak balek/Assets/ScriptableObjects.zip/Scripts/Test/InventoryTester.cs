
using UnityEngine;
using Game.Gameplay.Inventory;

public sealed class InventoryTester : MonoBehaviour
{
    [Header("Test Configuration")]
    [SerializeField] private ItemDefinition item;

    [SerializeField, Min(1)]
    private int quantity = 3;

    private InventoryState inventory;

    private void Awake()
    {
        inventory = new InventoryState();
    }

    // =====================================
    // ADD ITEM
    // =====================================

    [ContextMenu("Inventory/Add Selected Quantity")]
    private void AddSelectedQuantity()
    {
        if (!EnsureReady())
            return;

        inventory.AddItem(item, quantity);

        Debug.Log(
            $"Added {quantity}x {item.ItemName}",
            this
        );

        LogInventory();
    }

    // =====================================
    // REMOVE ITEM
    // =====================================

    [ContextMenu("Inventory/Remove One")]
    private void RemoveOne()
    {
        if (!EnsureReady())
            return;

        bool success = inventory.TryRemoveItem(item);

        Debug.Log(
            success
                ? $"Removed 1x {item.ItemName}"
                : $"Failed to remove {item.ItemName}",
            this
        );

        LogInventory();
    }

    [ContextMenu("Inventory/Remove Selected Quantity")]
    private void RemoveSelectedQuantity()
    {
        if (!EnsureReady())
            return;

        bool success = inventory.TryRemoveItem(
            item,
            quantity
        );

        Debug.Log(
            success
                ? $"Removed {quantity}x {item.ItemName}"
                : $"Not enough {item.ItemName}!",
            this
        );

        LogInventory();
    }

    // =====================================
    // CHECK INVENTORY
    // =====================================

    [ContextMenu("Inventory/Check Selected Item")]
    private void CheckSelectedItem()
    {
        if (!EnsureReady())
            return;

        int currentQuantity = inventory.GetQuantity(item);

        Debug.Log(
            $"Item: {item.ItemName}\n" +
            $"Quantity: {currentQuantity}\n" +
            $"Has Item: {inventory.HasItem(item)}",
            this
        );
    }

    [ContextMenu("Inventory/Check Empty")]
    private void CheckEmpty()
    {
        if (!EnsureInventory())
            return;

        Debug.Log(
            $"Inventory Empty: {inventory.IsEmpty}",
            this
        );
    }

    // =====================================
    // RESET
    // =====================================

    [ContextMenu("Inventory/Reset")]
    private void ResetInventory()
    {
        inventory = new InventoryState();

        Debug.Log("Inventory has been reset.", this);
        LogInventory();
    }

    // =====================================
    // DEBUG
    // =====================================

    private void LogInventory()
    {
        if (inventory.IsEmpty)
        {
            Debug.Log("Inventory is empty.", this);
            return;
        }

        string contents = "Current Inventory:\n";

        foreach (var entry in inventory.Items)
        {
            contents +=
                $"- {entry.Key.ItemName}: {entry.Value}\n";
        }

        Debug.Log(contents, this);
    }

    // =====================================
    // VALIDATION
    // =====================================

    private bool EnsureInventory()
    {
        inventory ??= new InventoryState();
        return true;
    }

    private bool EnsureReady()
    {
        EnsureInventory();

        if (item == null)
        {
            Debug.LogError(
                "Item Definition is missing!",
                this
            );

            return false;
        }

        return true;
    }
}
