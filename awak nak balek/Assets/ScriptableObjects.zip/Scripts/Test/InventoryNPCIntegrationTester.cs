
using System;
using UnityEngine;
using Game.Gameplay.NPC;
using Game.Gameplay.Inventory;

public sealed class InventoryNPCIntegrationTester : MonoBehaviour
{
    [Header("NPC Configuration")]
    [SerializeField] private NPCProfile profile;

    [Header("Item Configuration")]
    [SerializeField] private ItemDefinition testItem;

    [SerializeField, Min(1)]
    private int startingItemQuantity = 3;

    private NPCSessionState session;
    private NPCInteractionService npcInteraction;
    private InventoryState inventory;
    private InventoryService inventoryService;

    private void Awake()
    {
        ResetTest();
    }

    [ContextMenu("Integration/Show Selected Item")]
    private void TestShowItem()
    {
        if (!EnsureInitialized())
            return;

        InventoryActionResult result =
            inventoryService.TryShowItem(testItem);

        LogResult(result);
    }

    [ContextMenu("Integration/Reset Test")]
    private void ResetTest()
    {
        if (profile == null || testItem == null)
        {
            Debug.LogError(
                "Assign NPC Profile and Item Definition first!",
                this
            );

            return;
        }

        session = new NPCSessionState(profile);

        npcInteraction = new NPCInteractionService(
            session,
            new System.Random(123)
        );

        inventory = new InventoryState();

        inventory.AddItem(testItem, startingItemQuantity);

        inventoryService = new InventoryService(
            inventory,
            npcInteraction
        );

        Debug.Log("Integration test initialized.", this);
    }

    private bool EnsureInitialized()
    {
        return session != null &&
               inventory != null &&
               inventoryService != null;
    }

    private void LogResult(InventoryActionResult result)
    {
        string message =
            $"=== ITEM INTERACTION ===\n" +
            $"Success: {result.Succeeded}\n" +
            $"Failure: {result.Failure}\n" +
            $"Item: {result.Item.ItemName}\n" +
            $"Remaining Quantity: {result.RemainingQuantity}\n";

        if (result.InteractionResult != null)
        {
            NPCActionResult npcResult = result.InteractionResult;

            message +=
                $"\n=== NPC RESULT ===\n" +
                $"Mood: {npcResult.Mood}\n" +
                $"Resonance Change: {npcResult.ResonanceChange}\n" +
                $"Current Resonance: {session.Resonance}\n" +
                $"Turns Spent: {npcResult.TurnsSpent}\n" +
                $"Remaining Turns: {session.RemainingTurns}\n" +
                $"Offset: {npcResult.PreviousOffset} -> {npcResult.CurrentOffset}\n" +
                $"Status: {npcResult.SessionStatus}";
        }

        Debug.Log(message, this);
    }
}
