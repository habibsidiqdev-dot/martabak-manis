
using System;
using System.Collections.Generic;
using UnityEngine;
using Game.Core;
using Game.Gameplay.NPC;

public sealed class NPCServiceTester : MonoBehaviour
{
    [Header("Configuration")]
    [SerializeField] private NPCProfile profile;

    private NPCSessionState session;
    private NPCInteractionService interactionService;

    private string lastAction = "No action yet.";

    private void Awake()
    {
        InitializeSession();
    }

    private void InitializeSession()
    {
        if (profile == null)
        {
            Debug.LogError(
                "NPC Profile is missing!",
                this
            );

            enabled = false;
            return;
        }

        session = new NPCSessionState(profile);

        interactionService = new NPCInteractionService(
            session,
            new System.Random(123)
        );
    }

    // =====================================
    // APPROACH TESTING
    // =====================================

    private void ExecuteApproach(ApproachType approach)
    {
        NPCActionResult result =
            interactionService.TryChooseApproach(approach);

        lastAction = FormatResult(result);

        Debug.Log(lastAction, this);
    }

    // =====================================
    // ITEM TESTING
    // =====================================

    private void ExecuteShowItem(ApproachType approach)
    {
        NPCActionResult result =
            interactionService.TryShowItem(approach);

        lastAction = FormatResult(result);

        Debug.Log(lastAction, this);
    }

    // =====================================
    // DISCARD TESTING
    // =====================================

    private void ExecuteDiscardRotate()
    {
        bool success = interactionService.TryDiscardToRotate();

        lastAction = success
            ? "Discard Rotate: Success"
            : "Discard Rotate: Failed";

        Debug.Log(
            $"{lastAction}\nCurrent Offset: {session.Offset}",
            this
        );
    }

    private void ExecuteDiscardHold()
    {
        bool success = interactionService.TryDiscardToHold();

        lastAction = success
            ? "Discard Hold: Success"
            : "Discard Hold: Failed";

        Debug.Log(lastAction, this);
    }

    // =====================================
    // RESET
    // =====================================

    private void ResetSession()
    {
        session.Reset();

        // Recreate random provider for reproducible testing.
        interactionService = new NPCInteractionService(
            session,
            new System.Random(123)
        );

        lastAction = "Session Reset.";

        Debug.Log(lastAction, this);
    }

    // =====================================
    // RESULT FORMATTING
    // =====================================

    private string FormatResult(NPCActionResult result)
    {
        return
            $"Success: {result.Succeeded}\n" +
            $"Failure: {result.Failure}\n" +
            $"Approach: {result.Approach?.ToString() ?? "N/A"}\n" +
            $"Mood: {result.Mood?.ToString() ?? "N/A"}\n" +
            $"Resonance Change: {result.ResonanceChange}\n" +
            $"Current Resonance: {session.Resonance}\n" +
            $"Turns Spent: {result.TurnsSpent}\n" +
            $"Remaining Turns: {session.RemainingTurns}\n" +
            $"Offset: {result.PreviousOffset} -> {result.CurrentOffset}\n" +
            $"Rotation Held: {result.RotationWasHeld}\n" +
            $"Status: {result.SessionStatus}";
    }

    // =====================================
    // LOCKED APPROACH DISPLAY
    // =====================================

    private string GetLockedApproaches()
    {
        List<string> locked = new List<string>();

        foreach (ApproachType approach in
                 Enum.GetValues(typeof(ApproachType)))
        {
            if (session.IsApproachLocked(approach))
            {
                locked.Add(approach.ToString());
            }
        }

        return locked.Count == 0
            ? "None"
            : string.Join(", ", locked);
    }

    // =====================================
    // DEBUG UI
    // =====================================

    private void OnGUI()
    {
        if (!Application.isPlaying || session == null)
            return;

        GUILayout.BeginArea(
            new Rect(15, 15, 380, 700),
            "NPC Interaction Tester",
            GUI.skin.window
        );

        GUILayout.Space(10);

        GUILayout.Label("SESSION STATUS");
        GUILayout.Label($"Status: {session.Status}");
        GUILayout.Label($"Resonance: {session.Resonance} / {session.TargetResonance}");
        GUILayout.Label($"Turns: {session.RemainingTurns}");
        GUILayout.Label($"Offset: {session.Offset}");
        GUILayout.Label($"Locked: {GetLockedApproaches()}");

        GUILayout.Space(15);

        GUI.enabled = session.IsActive;

        GUILayout.Label("NORMAL APPROACH");

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Test OBS"))
            ExecuteApproach(ApproachType.Observation);

        if (GUILayout.Button("Test KNO"))
            ExecuteApproach(ApproachType.Knowledge);
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Test ACT"))
            ExecuteApproach(ApproachType.Action);

        if (GUILayout.Button("Test SIL"))
            ExecuteApproach(ApproachType.Silence);
        GUILayout.EndHorizontal();

        GUILayout.Space(15);

        GUILayout.Label("SHOW ITEM");

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Item OBS"))
            ExecuteShowItem(ApproachType.Observation);

        if (GUILayout.Button("Item KNO"))
            ExecuteShowItem(ApproachType.Knowledge);
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Item ACT"))
            ExecuteShowItem(ApproachType.Action);

        if (GUILayout.Button("Item SIL"))
            ExecuteShowItem(ApproachType.Silence);
        GUILayout.EndHorizontal();

        GUILayout.Space(15);

        GUILayout.Label("DISCARD ACTIONS");

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Discard: Rotate"))
            ExecuteDiscardRotate();

        if (GUILayout.Button("Discard: Hold"))
            ExecuteDiscardHold();
        GUILayout.EndHorizontal();

        GUI.enabled = true;

        GUILayout.Space(15);

        if (GUILayout.Button("RESET SESSION"))
        {
            ResetSession();
        }

        GUILayout.Space(15);

        GUILayout.Label("LAST ACTION");
        GUILayout.TextArea(lastAction, GUILayout.Height(150));

        GUILayout.EndArea();
    }
}
