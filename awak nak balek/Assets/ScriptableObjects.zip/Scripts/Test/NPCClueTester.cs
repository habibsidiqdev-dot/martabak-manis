
using UnityEngine;
using Game.Gameplay.NPC;

public sealed class NPCClueTester : MonoBehaviour
{
    [Header("Configuration")]
    [SerializeField] private NPCProfile profile;

    [Header("Testing")]
    [SerializeField, Range(0, 3)]
    private int testOffset;

    private NPCClueService clueService;

    private void Initialize()
    {
        if (profile == null)
        {
            Debug.LogError("NPC Profile is missing!", this);
            return;
        }

        clueService ??= new NPCClueService(profile);
    }

    [ContextMenu("Test Selected Offset")]
    private void TestSelectedOffset()
    {
        Initialize();

        if (clueService == null)
            return;

        NPCClueResult result = clueService.GetClues(testOffset);

        Debug.Log(
            $"===== OFFSET {result.Offset} =====\n\n" +
            $"First Clue:\n" +
            $"{result.FirstClue.Approach} " +
            $"({result.FirstClue.Mood})\n" +
            $"{result.FirstClue.Text}\n\n" +
            $"Second Clue:\n" +
            $"{result.SecondClue.Approach} " +
            $"({result.SecondClue.Mood})\n" +
            $"{result.SecondClue.Text}",
            this
        );
    }

    [ContextMenu("Test All Offsets")]
    private void TestAllOffsets()
    {
        Initialize();

        if (clueService == null)
            return;

        for (int offset = 0; offset < 4; offset++)
        {
            NPCClueResult result = clueService.GetClues(offset);

            Debug.Log(
                $"Offset: {offset}\n" +
                $"First: {result.FirstClue.Approach} " +
                $"({result.FirstClue.Mood})\n" +
                $"{result.FirstClue.Text}\n\n" +
                $"Second: {result.SecondClue.Approach} " +
                $"({result.SecondClue.Mood})\n" +
                $"{result.SecondClue.Text}",
                this
            );
        }
    }
}
