
namespace Game.Core
{
    /// <summary>
    /// Represents the NPC's reaction to an approach.
    /// Numeric values determine the mood rotation order.
    /// Do not change their order.
    /// </summary>
    public enum MoodType
    {
        VeryLike = 0,
        Like = 1,
        Neutral = 2,
        Rejected = 3
    }
}
