
namespace Game.Core
{
    /// <summary>
    /// Defines the four approaches available to the player.
    /// Numeric values are used by the mood rotation system.
    /// Do not change their order.
    /// </summary>
    public enum ApproachType
    {
        Observation = 0,
        Knowledge = 1,
        Action = 2,
        Silence = 3
    }
}
