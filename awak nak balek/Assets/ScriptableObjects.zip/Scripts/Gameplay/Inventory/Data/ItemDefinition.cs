
using Game.Core;
using UnityEngine;

namespace Game.Gameplay.Inventory
{
    /// <summary>
    /// Defines the static data of an inventory item.
    /// </summary>
    [CreateAssetMenu(
        fileName = "NewItem",
        menuName = "Game/Inventory/Item Definition"
    )]
    public sealed class ItemDefinition : ScriptableObject
    {
        [Header("Identity")]
        [SerializeField] private string itemName;

        [TextArea(2, 4)]
        [SerializeField] private string description;

        [Header("Item Appearance")]
        [SerializeField] private Sprite icon;

        [Header("Gameplay")]
        [SerializeField] private ApproachType approachType;

        public string ItemName => itemName;

        public string Description => description;

        public Sprite Icon => icon;

        public ApproachType ApproachType => approachType;
    }
}
