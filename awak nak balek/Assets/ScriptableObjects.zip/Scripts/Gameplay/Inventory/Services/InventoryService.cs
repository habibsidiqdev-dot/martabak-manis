
using System;
using Game.Gameplay.NPC;

namespace Game.Gameplay.Inventory
{
    /// <summary>
    /// Coordinates inventory usage with NPC interactions.
    /// </summary>
    public sealed class InventoryService
    {
        private readonly InventoryState inventory;

        private readonly NPCInteractionService npcInteraction;

        public InventoryService(
            InventoryState inventory,
            NPCInteractionService npcInteraction)
        {
            this.inventory = inventory ??
                throw new ArgumentNullException(nameof(inventory));

            this.npcInteraction = npcInteraction ??
                throw new ArgumentNullException(nameof(npcInteraction));
        }

        /// <summary>
        /// Attempts to show an item to the NPC.
        /// Consumes the item only when the interaction succeeds.
        /// </summary>
        public InventoryActionResult TryShowItem(
            ItemDefinition item)
        {
            if (item == null)
                throw new ArgumentNullException(nameof(item));

            int currentQuantity = inventory.GetQuantity(item);

            // Check item ownership.
            if (currentQuantity <= 0)
            {
                return CreateResult(
                    InventoryActionFailure.ItemNotOwned,
                    item,
                    currentQuantity,
                    null
                );
            }

            // Process the NPC interaction.
            NPCActionResult interactionResult =
                npcInteraction.TryShowItem(item.ApproachType);

            // Do not consume the item if interaction fails.
            if (!interactionResult.Succeeded)
            {
                return CreateResult(
                    InventoryActionFailure.NPCInteractionFailed,
                    item,
                    currentQuantity,
                    interactionResult
                );
            }

            // Consume one item after successful interaction.
            bool removed = inventory.TryRemoveItem(item);

            if (!removed)
            {
                throw new InvalidOperationException(
                    "Inventory changed unexpectedly during item usage."
                );
            }

            return CreateResult(
                InventoryActionFailure.None,
                item,
                inventory.GetQuantity(item),
                interactionResult
            );
        }

        private static InventoryActionResult CreateResult(
            InventoryActionFailure failure,
            ItemDefinition item,
            int remainingQuantity,
            NPCActionResult interactionResult)
        {
            return new InventoryActionResult(
                failure,
                item,
                remainingQuantity,
                interactionResult
            );
        }
    }
}
