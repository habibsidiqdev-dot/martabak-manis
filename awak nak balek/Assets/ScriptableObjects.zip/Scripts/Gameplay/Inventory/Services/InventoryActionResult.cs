
using Game.Gameplay.NPC;

namespace Game.Gameplay.Inventory
{
    public sealed class InventoryActionResult
    {
        public bool Succeeded =>
            Failure == InventoryActionFailure.None;

        public InventoryActionFailure Failure { get; }

        public ItemDefinition Item { get; }

        public int RemainingQuantity { get; }

        public NPCActionResult InteractionResult { get; }

        internal InventoryActionResult(
            InventoryActionFailure failure,
            ItemDefinition item,
            int remainingQuantity,
            NPCActionResult interactionResult)
        {
            Failure = failure;
            Item = item;
            RemainingQuantity = remainingQuantity;
            InteractionResult = interactionResult;
        }
    }
}
