
namespace Game.Gameplay.Inventory
{
    public enum InventoryActionFailure
    {
        None,
        ItemNotOwned,
        NPCInteractionFailed
    }
}
