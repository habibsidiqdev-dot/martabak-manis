
using System;
using System.Collections.Generic;

namespace Game.Gameplay.Inventory
{
    /// <summary>
    /// Stores the runtime inventory of the player.
    /// Each item definition is associated with its quantity.
    /// </summary>
    public sealed class InventoryState
    {
        private readonly Dictionary<ItemDefinition, int> items =
            new Dictionary<ItemDefinition, int>();

        /// <summary>
        /// Read-only access to inventory contents.
        /// </summary>
        public IReadOnlyDictionary<ItemDefinition, int> Items => items;

        /// <summary>
        /// Returns true when the inventory contains no items.
        /// </summary>
        public bool IsEmpty => items.Count == 0;

        /// <summary>
        /// Adds an item to the inventory.
        /// Existing quantities will be increased.
        /// </summary>
        public void AddItem(
            ItemDefinition item,
            int quantity = 1)
        {
            if (item == null)
                throw new ArgumentNullException(nameof(item));

            if (quantity <= 0)
                throw new ArgumentOutOfRangeException(
                    nameof(quantity),
                    "Quantity must be greater than zero."
                );

            if (items.TryGetValue(item, out int currentQuantity))
            {
                items[item] = checked(currentQuantity + quantity);
            }
            else
            {
                items.Add(item, quantity);
            }
        }

        /// <summary>
        /// Attempts to remove an item from the inventory.
        /// Returns false if the requested quantity is unavailable.
        /// </summary>
        public bool TryRemoveItem(
            ItemDefinition item,
            int quantity = 1)
        {
            if (item == null)
                throw new ArgumentNullException(nameof(item));

            if (quantity <= 0)
                throw new ArgumentOutOfRangeException(
                    nameof(quantity),
                    "Quantity must be greater than zero."
                );

            if (!items.TryGetValue(item, out int currentQuantity))
                return false;

            if (currentQuantity < quantity)
                return false;

            int remainingQuantity = currentQuantity - quantity;

            if (remainingQuantity == 0)
            {
                items.Remove(item);
            }
            else
            {
                items[item] = remainingQuantity;
            }

            return true;
        }

        /// <summary>
        /// Returns the quantity of a specific item.
        /// Returns zero if the item is not owned.
        /// </summary>
        public int GetQuantity(ItemDefinition item)
        {
            if (item == null)
                throw new ArgumentNullException(nameof(item));

            return items.TryGetValue(item, out int quantity)
                ? quantity
                : 0;
        }

        /// <summary>
        /// Checks whether the inventory contains an item.
        /// </summary>
        public bool HasItem(ItemDefinition item)
        {
            return GetQuantity(item) > 0;
        }
    }
}
