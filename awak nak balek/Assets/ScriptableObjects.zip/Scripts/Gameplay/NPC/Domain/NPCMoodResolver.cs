
using System;
using Game.Core;

namespace Game.Gameplay.NPC
{
    /// <summary>
    /// Resolves NPC moods based on approach type and rotation offset.
    /// This class contains pure gameplay logic.
    /// </summary>
    public static class NPCMoodResolver
    {
        private const int ApproachCount = 4;

        /// <summary>
        /// Gets the mood associated with an approach.
        /// </summary>
        public static MoodType GetMood(
            ApproachType approach,
            int offset)
        {
            ValidateApproach(approach);

            int normalizedOffset = PositiveModulo(
                offset,
                ApproachCount
            );

            int moodIndex = PositiveModulo(
                (int)approach - normalizedOffset,
                ApproachCount
            );

            return (MoodType)moodIndex;
        }

        /// <summary>
        /// Gets the approach associated with a specific mood.
        /// </summary>
        public static ApproachType GetApproachByMood(
            MoodType mood,
            int offset)
        {
            ValidateMood(mood);

            int normalizedOffset = PositiveModulo(
                offset,
                ApproachCount
            );

            int approachIndex = PositiveModulo(
                normalizedOffset + (int)mood,
                ApproachCount
            );

            return (ApproachType)approachIndex;
        }

        private static int PositiveModulo(int value, int modulo)
        {
            return (value % modulo + modulo) % modulo;
        }

        private static void ValidateApproach(ApproachType approach)
        {
            if ((int)approach < 0 || (int)approach >= ApproachCount)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(approach),
                    approach,
                    "Invalid approach type."
                );
            }
        }

        private static void ValidateMood(MoodType mood)
        {
            if ((int)mood < 0 || (int)mood >= ApproachCount)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(mood),
                    mood,
                    "Invalid mood type."
                );
            }
        }
    }
}
