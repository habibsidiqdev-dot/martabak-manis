using System;
using Game.Core;

namespace Game.Gameplay.NPC
{
    /// <summary>
    /// Represents one generated NPC body-language clue.
    /// </summary>
    public sealed class NPCClue
    {
        public ApproachType Approach { get; }

        public MoodType Mood { get; }

        public string Text { get; }

        public NPCClue(
            ApproachType approach,
            MoodType mood,
            string text)
        {
            Approach = approach;
            Mood = mood;

            Text = !string.IsNullOrWhiteSpace(text)
                ? text
                : throw new ArgumentException(
                    "Clue text cannot be empty.",
                    nameof(text)
                );
        }
    }
}