using System;
using System.Collections.Generic;
using Game.Core;

namespace Game.Gameplay.NPC
{
    /// <summary>
    /// Stores mutable runtime data for one NPC interaction session.
    /// This class does not depend on MonoBehaviour or Unity Scene objects.
    /// </summary>
    public sealed class NPCSessionState
    {
        private readonly NPCProfile profile;

        private readonly HashSet<ApproachType> lockedApproaches =
            new HashSet<ApproachType>();

        public int Resonance { get; private set; }

        public int RemainingTurns { get; private set; }

        public int Offset { get; private set; }

        public bool HoldNextRotation { get; private set; }

        public NPCSessionStatus Status { get; private set; }

        public int TargetResonance => profile.ResonanceTarget;

        public bool IsActive => Status == NPCSessionStatus.Active;

        public NPCSessionState(NPCProfile profile)
        {
            this.profile = profile != null
                ? profile
                : throw new ArgumentNullException(nameof(profile));

            Reset();
        }

        // -------------------------
        // SESSION MANAGEMENT
        // -------------------------

        public void Reset()
        {
            Resonance = 0;
            RemainingTurns = profile.StartingTurns;
            Offset = 0;

            HoldNextRotation = false;

            lockedApproaches.Clear();

            Status = NPCSessionStatus.Active;
        }

        // -------------------------
        // RESONANCE
        // -------------------------

        public void AddResonance(int amount)
        {
            EnsureActive();

            Resonance = Math.Max(0, Resonance + amount);
        }

        // -------------------------
        // TURN MANAGEMENT
        // -------------------------

        public void SpendTurn()
        {
            EnsureActive();

            RemainingTurns = Math.Max(0, RemainingTurns - 1);
        }

        // -------------------------
        // ROTATION MANAGEMENT
        // -------------------------

        public void AdvanceOffset()
        {
            EnsureActive();

            Offset++;
        }

        public void HoldRotation()
        {
            EnsureActive();

            HoldNextRotation = true;
        }

        public bool ConsumeHold()
        {
            EnsureActive();

            if (!HoldNextRotation)
                return false;

            HoldNextRotation = false;

            return true;
        }

        // -------------------------
        // APPROACH LOCK
        // -------------------------

        public bool IsApproachLocked(ApproachType approach)
        {
            return lockedApproaches.Contains(approach);
        }

        public void LockApproach(ApproachType approach)
        {
            EnsureActive();

            lockedApproaches.Add(approach);
        }

        // -------------------------
        // SESSION RESULT
        // -------------------------

        public void MarkWon()
        {
            EnsureActive();

            Status = NPCSessionStatus.Won;
        }

        public void MarkLost()
        {
            EnsureActive();

            Status = NPCSessionStatus.Lost;
        }

        // -------------------------
        // VALIDATION
        // -------------------------

        private void EnsureActive()
        {
            if (!IsActive)
            {
                throw new InvalidOperationException(
                    "NPC session is no longer active."
                );
            }
        }
    }
}