namespace Game.Gameplay.NPC
{
    /// <summary>
    /// Contains the two clues displayed to the player.
    /// </summary>
    public sealed class NPCClueResult
    {
        public NPCClue FirstClue { get; }

        public NPCClue SecondClue { get; }

        public int Offset { get; }

        public NPCClueResult(
            NPCClue firstClue,
            NPCClue secondClue,
            int offset)
        {
            FirstClue = firstClue;
            SecondClue = secondClue;
            Offset = offset;
        }
    }
}