namespace Game.Gameplay.NPC
{
    public enum NPCSessionStatus
    {
        Active,
        Won,
        Lost
    }
}