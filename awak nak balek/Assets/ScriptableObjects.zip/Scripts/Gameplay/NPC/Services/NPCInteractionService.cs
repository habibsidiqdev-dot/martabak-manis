
using System;
using Game.Core;

namespace Game.Gameplay.NPC
{
    /// <summary>
    /// Handles gameplay rules for NPC interactions.
    /// Does not depend on UnityEngine or presentation systems.
    /// </summary>
    public sealed class NPCInteractionService
    {
        private readonly NPCSessionState session;
        private readonly Random random;

        public NPCInteractionService(
            NPCSessionState session,
            Random random = null)
        {
            this.session = session ??
                throw new ArgumentNullException(nameof(session));

            this.random = random ?? new Random();
        }

        // =====================================
        // NORMAL APPROACH
        // =====================================

        public NPCActionResult TryChooseApproach(
            ApproachType approach)
        {
            if (!session.IsActive)
            {
                return CreateFailure(
                    NPCActionFailure.SessionNotActive,
                    false,
                    approach
                );
            }

            if (session.IsApproachLocked(approach))
            {
                return CreateFailure(
                    NPCActionFailure.ApproachLocked,
                    false,
                    approach
                );
            }

            MoodType mood = NPCMoodResolver.GetMood(
                approach,
                session.Offset
            );

            int previousResonance = session.Resonance;
            int previousOffset = session.Offset;

            int turnsSpent = 0;

            // Apply mood effects.
            switch (mood)
            {
                case MoodType.VeryLike:
                    session.AddResonance(3);
                    break;

                case MoodType.Like:
                    int reward = random.Next(1, 3);

                    session.AddResonance(reward);
                    session.SpendTurn();

                    turnsSpent = 1;
                    break;

                case MoodType.Neutral:
                    session.SpendTurn();

                    turnsSpent = 1;
                    break;

                case MoodType.Rejected:
                    session.AddResonance(-2);
                    session.SpendTurn();
                    session.LockApproach(approach);

                    turnsSpent = 1;
                    break;

                default:
                    throw new ArgumentOutOfRangeException(
                        nameof(mood),
                        mood,
                        "Unsupported mood type."
                    );
            }

            bool rotationWasHeld = RotateAfterAction();

            ResolveSessionOutcome();

            return CreateSuccess(
                false,
                approach,
                mood,
                previousResonance,
                turnsSpent,
                rotationWasHeld,
                previousOffset
            );
        }

        // =====================================
        // SHOW ITEM
        // =====================================

        public NPCActionResult TryShowItem(
            ApproachType itemApproach)
        {
            if (!session.IsActive)
            {
                return CreateFailure(
                    NPCActionFailure.SessionNotActive,
                    true,
                    itemApproach
                );
            }

            MoodType mood = NPCMoodResolver.GetMood(
                itemApproach,
                session.Offset
            );

            int previousResonance = session.Resonance;
            int previousOffset = session.Offset;

            int turnsSpent = 0;

            // Item always gives +4 resonance.
            session.AddResonance(4);

            // Very Like makes showing the item free.
            if (mood != MoodType.VeryLike)
            {
                session.SpendTurn();
                turnsSpent = 1;
            }

            bool rotationWasHeld = RotateAfterAction();

            ResolveSessionOutcome();

            return CreateSuccess(
                true,
                itemApproach,
                mood,
                previousResonance,
                turnsSpent,
                rotationWasHeld,
                previousOffset
            );
        }

        // =====================================
        // DISCARD: ROTATE WHEEL
        // =====================================

        public bool TryDiscardToRotate()
        {
            if (!session.IsActive)
                return false;

            // Manual rotation always works.
            // It does not consume a pending hold.
            session.AdvanceOffset();

            return true;
        }

        // =====================================
        // DISCARD: HOLD WHEEL
        // =====================================

        public bool TryDiscardToHold()
        {
            if (!session.IsActive)
                return false;

            session.HoldRotation();

            return true;
        }

        // =====================================
        // AUTOMATIC ROTATION
        // =====================================

        private bool RotateAfterAction()
        {
            if (session.ConsumeHold())
                return true;

            session.AdvanceOffset();

            return false;
        }

        // =====================================
        // WIN / LOSE
        // =====================================

        private void ResolveSessionOutcome()
        {
            // Victory must always be checked first.
            if (session.Resonance >= session.TargetResonance)
            {
                session.MarkWon();
                return;
            }

            if (session.RemainingTurns <= 0)
            {
                session.MarkLost();
            }
        }

        // =====================================
        // RESULT FACTORIES
        // =====================================

        private NPCActionResult CreateSuccess(
            bool isItemAction,
            ApproachType approach,
            MoodType mood,
            int previousResonance,
            int turnsSpent,
            bool rotationWasHeld,
            int previousOffset)
        {
            return new NPCActionResult(
                NPCActionFailure.None,
                isItemAction,
                approach,
                mood,
                session.Resonance - previousResonance,
                turnsSpent,
                rotationWasHeld,
                previousOffset,
                session.Offset,
                session.Status
            );
        }

        private NPCActionResult CreateFailure(
            NPCActionFailure failure,
            bool isItemAction,
            ApproachType approach)
        {
            return new NPCActionResult(
                failure,
                isItemAction,
                approach,
                null,
                0,
                0,
                false,
                session.Offset,
                session.Offset,
                session.Status
            );
        }
    }
}
