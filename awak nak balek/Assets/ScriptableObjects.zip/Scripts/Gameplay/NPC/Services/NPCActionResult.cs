
using Game.Core;

namespace Game.Gameplay.NPC
{
    /// <summary>
    /// Immutable result of an NPC interaction action.
    /// </summary>
    public sealed class NPCActionResult
    {
        public bool Succeeded =>
            Failure == NPCActionFailure.None;

        public NPCActionFailure Failure { get; }

        public bool IsItemAction { get; }

        public ApproachType? Approach { get; }

        public MoodType? Mood { get; }

        public int ResonanceChange { get; }

        public int TurnsSpent { get; }

        public bool RotationWasHeld { get; }

        public int PreviousOffset { get; }

        public int CurrentOffset { get; }

        public NPCSessionStatus SessionStatus { get; }

        internal NPCActionResult(
            NPCActionFailure failure,
            bool isItemAction,
            ApproachType? approach,
            MoodType? mood,
            int resonanceChange,
            int turnsSpent,
            bool rotationWasHeld,
            int previousOffset,
            int currentOffset,
            NPCSessionStatus sessionStatus)
        {
            Failure = failure;
            IsItemAction = isItemAction;
            Approach = approach;
            Mood = mood;
            ResonanceChange = resonanceChange;
            TurnsSpent = turnsSpent;
            RotationWasHeld = rotationWasHeld;
            PreviousOffset = previousOffset;
            CurrentOffset = currentOffset;
            SessionStatus = sessionStatus;
        }
    }
}
