
using System;
using Game.Core;

namespace Game.Gameplay.NPC
{
    /// <summary>
    /// Generates body-language clues based on the current NPC offset.
    /// </summary>
    public sealed class NPCClueService
    {
        private readonly NPCProfile profile;

        public NPCClueService(NPCProfile profile)
        {
            this.profile = profile ??
                throw new ArgumentNullException(nameof(profile));
        }

        public NPCClueResult GetClues(int offset)
        {
            // Normalize offset to the range 0-3.
            int normalizedOffset = PositiveModulo(offset, 4);

            // Find the approaches associated with each mood.
            ApproachType positiveApproach =
                NPCMoodResolver.GetApproachByMood(
                    MoodType.VeryLike,
                    normalizedOffset
                );

            ApproachType negativeApproach =
                NPCMoodResolver.GetApproachByMood(
                    MoodType.Rejected,
                    normalizedOffset
                );

            // Retrieve clue texts from NPC profile.
            NPCClue positiveClue = new NPCClue(
                positiveApproach,
                MoodType.VeryLike,
                profile.GetClueText(
                    positiveApproach,
                    MoodType.VeryLike
                )
            );

            NPCClue negativeClue = new NPCClue(
                negativeApproach,
                MoodType.Rejected,
                profile.GetClueText(
                    negativeApproach,
                    MoodType.Rejected
                )
            );

            // Reverse the display order on odd offsets.
            bool reverseOrder = normalizedOffset % 2 == 1;

            if (reverseOrder)
            {
                return new NPCClueResult(
                    negativeClue,
                    positiveClue,
                    normalizedOffset
                );
            }

            return new NPCClueResult(
                positiveClue,
                negativeClue,
                normalizedOffset
            );
        }

        private static int PositiveModulo(int value, int modulo)
        {
            return (value % modulo + modulo) % modulo;
        }
    }
}
