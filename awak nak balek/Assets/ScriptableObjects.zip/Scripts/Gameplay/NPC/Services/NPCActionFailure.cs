
namespace Game.Gameplay.NPC
{
    public enum NPCActionFailure
    {
        None,
        SessionNotActive,
        ApproachLocked
    }
}
