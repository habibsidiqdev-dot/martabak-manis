using System;
using Game.Core;
using UnityEngine;

namespace Game.Gameplay.NPC
{
    [Serializable]
    public sealed class NPCApproachClueData
    {
        [Header("Positive Clue")]
        [SerializeField, TextArea(2, 4)]
        private string veryLikeText;

        [Header("Negative Clue")]
        [SerializeField, TextArea(2, 4)]
        private string rejectedText;

        public string GetText(MoodType mood)
        {
            switch (mood)
            {
                case MoodType.VeryLike:
                    return veryLikeText;

                case MoodType.Rejected:
                    return rejectedText;

                default:
                    throw new ArgumentOutOfRangeException(
                        nameof(mood),
                        mood,
                        "Only VeryLike and Rejected clues are supported."
                    );
            }
        }
    }
}