
using System;
using UnityEngine;
using Game.Core;

namespace Game.Gameplay.NPC
{
    [CreateAssetMenu(
        fileName = "NPCProfile",
        menuName = "Game/NPC Profile"
    )]
    public sealed class NPCProfile : ScriptableObject
    {
        [Header("Identity")]
        [SerializeField] private string displayName;

        [Header("Gameplay Configuration")]
        [SerializeField, Min(1)]
        private int resonanceTarget = 10;

        [SerializeField, Min(1)]
        private int startingTurns = 5;

        [Header("Body Language Clues")]
        [SerializeField]
        private NPCApproachClueData observationClues =
            new NPCApproachClueData();

        [SerializeField]
        private NPCApproachClueData knowledgeClues =
            new NPCApproachClueData();

        [SerializeField]
        private NPCApproachClueData actionClues =
            new NPCApproachClueData();

        [SerializeField]
        private NPCApproachClueData silenceClues =
            new NPCApproachClueData();

        public string DisplayName => displayName;

        public int ResonanceTarget => resonanceTarget;

        public int StartingTurns => startingTurns;

        /// <summary>
        /// Returns the clue text for a specific approach and mood.
        /// </summary>
        public string GetClueText(
            ApproachType approach,
            MoodType mood)
        {
            NPCApproachClueData clueData = approach switch
            {
                ApproachType.Observation => observationClues,
                ApproachType.Knowledge => knowledgeClues,
                ApproachType.Action => actionClues,
                ApproachType.Silence => silenceClues,

                _ => throw new ArgumentOutOfRangeException(
                    nameof(approach),
                    approach,
                    "Invalid approach type."
                )
            };

            if (clueData == null)
            {
                throw new InvalidOperationException(
                    $"Clue data for {approach} is missing."
                );
            }

            string clueText = clueData.GetText(mood);

            if (string.IsNullOrWhiteSpace(clueText))
            {
                throw new InvalidOperationException(
                    $"Clue text for {approach} / {mood} is empty."
                );
            }

            return clueText;
        }

        private void OnValidate()
        {
            resonanceTarget = Mathf.Max(1, resonanceTarget);
            startingTurns = Mathf.Max(1, startingTurns);
        }
    }
}
